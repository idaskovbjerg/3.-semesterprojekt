﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ST2Prj2LibNI_DAQ;

namespace PulsMaalerSystem.Datalag
{
    public class DataLag
    {
        NI_DAQVoltage DAQ = new NI_DAQVoltage();

        public DataLag()
        {

        }

        public List<double> hentBTdata()
        {
            DAQ.deviceName = "Dev1/AI0";
            DAQ.sampleRateInHz = 50;
            DAQ.samplesPerChannel = 100;
            DAQ.getVoltageSeqBlocking();
            return DAQ.currentVoltageSeq;
        }
        public List<double> hentEKGdata()
        {
            DAQ.deviceName = "Dev1/AI2";
            DAQ.sampleRateInHz = 50;
            DAQ.samplesPerChannel = 100;
            DAQ.getVoltageSeqBlocking();
            return DAQ.currentVoltageSeq;
        }
    }
}
