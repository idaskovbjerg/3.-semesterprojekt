﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
using PulsMaalerSystem.DTOlag;

namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag
    {
        DataLag data = new DataLag();

        public LogikLag()
        {

        }

        public List<double> hentBTdata()
        {
            return data.hentBTdata();
        }

        public List<double> hentEKGdata()
        {
            return data.hentEKGdata();
        }
    }
}
