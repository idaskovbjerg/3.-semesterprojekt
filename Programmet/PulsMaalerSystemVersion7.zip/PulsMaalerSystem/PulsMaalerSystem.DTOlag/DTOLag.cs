﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem
{
    public class DTOlag
    {
        private double voltage_;
        private double time_;

        public DTOlag(double time, double voltage)
        {
            time_ = time;
            voltage_ = voltage;
        }
        public void setVoltage(double voltage)
        {
            voltage_ = voltage;
        }

        public double getVoltage()
        {
            return voltage_;
        }

        public void setTime(double time)
        {
            time_ = time;
        }

        public double getTime()
        {
            return time_;
        }

        public override string ToString()
        {
            return "Time: " + time_ + "    -    Voltage: " + voltage_;
        }
    }
}