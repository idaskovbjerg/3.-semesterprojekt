﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using System.Threading;

namespace PulsMaalerSystem
{
    public partial class HovedGUI : Form
    {
        LogikLag logik;
        Thread VisEKG;
        Thread VisBT;
        TimeSpan tidTæller;
        private string brugernavn;
        public string port = "";
        double max = 5;
        double min = -5;
        double rate = 1000;
        int sample = 10;
        Thread traadeUpdateGUI;
        List<double> Blodtrykliste;


        public HovedGUI(string brugernavn)
        {
            InitializeComponent();

            Blodtrykliste = new List<double>();

            tidTextBox.ForeColor = tidTextBox.ForeColor;
            tidTextBox.BackColor = tidTextBox.BackColor;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTextBox.ReadOnly  = true;

         traadeUpdateGUI = new Thread(() => GUIUpdate());
        
            this.brugernavn = brugernavn;
            logik = new LogikLag();
            tidTæller = new TimeSpan();
            //VisEKG = new Thread(TrådEKG);
            //VisBT = new Thread(TrådBT);

            
            //List<double> EKGliste = logik.hentEKGdata();

        }

        private void GUIUpdate()
        {
             while (logik.isRunning())
             {
                 Blodtrykliste = logik.blodtrykVaerdi();
                 updateChart();
                 Thread.Sleep(1);
             }
    
        }

        private delegate void UpdateUICallback();

        private void updateChart()
        {
            if(Blodtryk.InvokeRequired)
            {
                UpdateUICallback d = new UpdateUICallback(updateChart);
                this.Invoke(d);
            }
            else
            {
                if(Blodtrykliste.Count > 501)
                {
                    Blodtryk.Series["Arterietryk"].Points.Clear();
                    Blodtryk.Series["Arterietryk"].Points.DataBindY(Blodtrykliste.GetRange(Blodtrykliste.Count - 501, 500));
                }
                
            }
        }



        //public void TrådEKG()
        //{
        //    EKG.Series["EKG-signal"].Points.DataBindY(logik.hentEKGdata());
        //}

        //public void TrådBT()
        //{
        //    Blodtryk.Series["Blodtryk-signal"].Points.DataBindY(logik.hentBTdata());
        //}


        private void timer1_Tick(object sender, EventArgs e)
        {
            tidTextBox.Text = tidTæller.ToString();
            tidTextBox.ForeColor = Color.White;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTæller += new TimeSpan(0, 0, 1);
        }

        private void tandKnap_Click(object sender, EventArgs e)
        {
            logik.hentBTdata(port, min, max, rate, sample);
            //VisEKG.Start();
            //VisBT.Start();
            tidTæller = new TimeSpan();
            timer1.Start();

            tandKnap.Enabled = false;
            slukKnap.Enabled = true;
            filterOff.Enabled = true;
            nulpunktKnap.Enabled = true;

            
            traadeUpdateGUI.Start();

        }

        private void slukKnap_Click(object sender, EventArgs e)
        {
            slukKnap.Enabled = false;
            tandKnap.Enabled = true;
            afbrydKnap.Enabled = true;
            nulpunktKnap.Enabled = false;
            
            timer1.Stop();
            logik.stopHentData();
            traadeUpdateGUI.Abort();
        }

        private void filterOff_Click(object sender, EventArgs e)
        {
            if (filterOff.Text.Equals("ON"))
            {
                filterOff.Text = "OFF";
            }

            else
            {
                filterOff.Text = "ON";
            }
        }

        private void afbrydKnap_Click(object sender, EventArgs e)
        {
            StartGUI Startskærm = new StartGUI();

            if(MessageBox.Show("Er du sikker?","Bekræft",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Startskærm.Show();
                this.Hide();
            }
           
            
        }


    }


}
