﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
using PulsMaalerSystem.DTOlag;
using System.Data;
using PulsMaalerSystem;


namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag
    {
        DataLag data = new DataLag();
        DTOlag dtoLag;
        private double time;
        private double voltage;
        private double toppunkt;
        private List<DTOlag> toppunkter;

        
        //Analyser toppunkter
        private double voltOverGennemsnit;


        public LogikLag()
        {
            time = 0;
            voltage = 0;
            dtoLag = new DTOlag(time,voltage);
            toppunkter = new List<DTOlag>();
            toppunkt = 0;
            voltOverGennemsnit = 3; //Ca. skal beregnes
        }

        public void findTopPunkt()
        {
            toppunkter.Clear();
            hentBTdata();


        }

        public List<double> hentBTdata(string port, double min, double max, double rate, int sample)
        {

            return data.hentBTdata(port, min, max, rate, sample);
        }

        //public List<double> hentEKGdata()
        //{
        //    return data.hentEKGdata();
        //}
        public bool getKode(string brugernavn, int kode)
        {
            return (kode.Equals(data.getKode(brugernavn)));

        }
        public string getCPR(string cpr, string valgtNavn)
        {
            return cpr; 
        }
        public bool isRunning()
        {
            return data.isRunning();
        }
        public void stopHentData()
        {
            data.stopHentData();
        }
        public List<double> blodtrykVaerdi()
        {
            return data.blodtrykVaerdi();
        }
        public List<string> listePatient(string brugernavn)
        {
            return data.PatientOpslag(brugernavn);
        }
        
    }
}
