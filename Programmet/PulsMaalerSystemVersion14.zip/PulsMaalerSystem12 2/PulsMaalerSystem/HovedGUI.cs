﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using System.Threading;
using PulsMaalerSystem.DTOlag;

namespace PulsMaalerSystem
{
    public partial class HovedGUI : Form, IObserver
    {
        LogikLag logik;
        TimeSpan tidTæller;
        private string brugernavn;
        public string port = "";
        double max = 5;
        double min = -5;
        double rate = 1000;
        int sample = 50;       
        double[] Blodtrykliste;
        int grænseværdiSysOp;
        int grænseværdiSysNed;
        int grænseværdiDiaOp;
        int grænseværdiDiaNed;


        public HovedGUI(string brugernavn)
        {
            InitializeComponent();

            Blodtrykliste = new double[500];

            tidTextBox.ForeColor = tidTextBox.ForeColor;
            tidTextBox.BackColor = tidTextBox.BackColor;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTextBox.ReadOnly  = true;
            grænseværdiSysOp = 140;
            grænseværdiSysNed = 100;
            grænseværdiDiaOp = 90;
            grænseværdiDiaNed = 60;
    
        
            this.brugernavn = brugernavn;
            logik = new LogikLag();
            tidTæller = new TimeSpan();
            
            
        }



 

        private delegate void UpdateUICallback();

        private void updateChart()
        {
            if(Blodtryk.InvokeRequired)
            {
                UpdateUICallback d = new UpdateUICallback(updateChart);
                this.Invoke(d);
            }
            else
            {
                if(Blodtrykliste.Length == 500)
                {
                    Blodtryk.Series["Arterietryk"].Points.Clear();
                    Blodtryk.Series["Arterietryk"].Points.DataBindY(Blodtrykliste);
                }
                
            }
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            tidTextBox.Text = tidTæller.ToString();
            tidTextBox.ForeColor = Color.White;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTæller += new TimeSpan(0, 0, 1);
        }

        private void tandKnap_Click(object sender, EventArgs e) 
        {
            logik.hentBTdata(port, min, max, rate, sample);
            tidTæller = new TimeSpan();
            timer1.Start();

            tandKnap.Enabled = false;
            slukKnap.Enabled = true;
            filterOff.Enabled = true;
            nulpunktKnap.Enabled = true;

            
           

        }

        private void slukKnap_Click(object sender, EventArgs e)
        {
            slukKnap.Enabled = false;
            tandKnap.Enabled = true;
            afbrydKnap.Enabled = true;
            nulpunktKnap.Enabled = false;
            
            timer1.Stop();
            //logik.StopHentData();
           
        }

        private void filterOff_Click(object sender, EventArgs e)
        {
            if (filterOff.Text.Equals("ON"))
            {
                filterOff.Text = "OFF";
            }

            else
            {
                filterOff.Text = "ON";
            }
        }

        private void afbrydKnap_Click(object sender, EventArgs e)
        {
            StartGUI Startskærm = new StartGUI();

            if(MessageBox.Show("Er du sikker?","Bekræft",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Startskærm.Show();
                this.Hide();
            }
           
            
        }

        private void nulpunktKnap_Click(object sender, EventArgs e)
        {
            //updateChart()
        }


        private void Alarm()
        {
            Console.Beep(500, 6000);// duration skal ændres til at være så længe grænseværdien er overskredet 
            // skal også update visbtdata
        }

        private void alarmKnap_Click(object sender, EventArgs e)
        {

        }

        private void VisBTdata()
        {

        }

        private void VisPuls()
        {

        }

        private void systoleOP_Click(object sender, EventArgs e)
        {
            //grænseværdiSysOp ++;
            //grænseværdiSysNed ++;
            //return grænseværdiSysOp;
            //return grænseværdiSysNed; 
            //sysOpLabel.Text = Convert.ToString(grænseværdiSysOp);
            //sysNedLabel.Text = Convert.ToString(grænseværdiSysNed);
        }

        private void diastoleNED_Click(object sender, EventArgs e)
        {

        }

        private void diastoleOP_Click(object sender, EventArgs e)
        {

        }

        private void systoleNED_Click(object sender, EventArgs e)
        {
            //grænseværdiSysOp --;
            //grænseværdiSysNed --;
            //return grænseværdiSysOp;
            //return grænseværdiSysNed;
            //sysOpLabel.Text = Convert.ToString(grænseværdiSysOp);
            //sysNedLabel.Text = Convert.ToString(grænseværdiSysNed);
        }



        public void Update(double[] graf)
        {
            Blodtrykliste = graf;
            updateChart();
        }
    }


}
