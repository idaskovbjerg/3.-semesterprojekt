﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PulsMaalerSystem.Datalag
{
    public class DataLag
    {

        private SqlConnection connpatient;
        private SqlConnection connpersonale;
        private SqlDataReader rdr;
        private SqlCommand cmd;

        private const String dbPersonale = "F15ST2ITS2201404669"; // Tilrettes DB
        private const String dbPatient = "F15ST2ITS2201405838"; // Tilrettes DB

        private ST3DAQ voresDaq;
        public ST3DAQ DAQ { get { return voresDaq; } }

        public DataLag()
        {
            // Opsætning af DB forbindelsen til SQL Server webhotel10.iha.dk og valgt database (db)
            connpersonale = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + dbPersonale + ";Persist Security Info=True;User ID=" + dbPersonale + ";Password=" + dbPersonale + "");
            connpatient = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + dbPatient +  ";Persist Security Info=True;User ID=" + dbPatient + ";Password=" + dbPatient + "" );
            voresDaq = new ST3DAQ();

        }
            
      
        public int  BrugernavnOpslag(string brugernavn)
        {
            int brugerResultat = 0;

            // Oprette
            cmd = new SqlCommand("select * from Personale where Brugernavn ='" + brugernavn + "'", connpersonale);

            connpersonale.Open();

            // Udføre 
            rdr = cmd.ExecuteReader();

            // Undersøge
            if (rdr.Read())
            {
                if (Convert.ToBoolean(rdr["Brugernavn"]))  // her udvælges kolonnen i resultattabellen med rdr[1], som converteres fra SQL-typen bit til C# typen boolean
                    brugerResultat = 1; // Brugernavn er OK og registreret
                else
                    brugerResultat = 2; // Brugernavn er ikke OK
            }

            // Lukke
            connpersonale.Close();
            return brugerResultat;
        }

        public List<string> PatientOpslag(string brugernavn)
        {
            
            cmd = new SqlCommand("select * from Patient where Sundhedsfaglig_personale ='" + brugernavn + "'", connpatient);
            connpatient.Open();
            rdr = cmd.ExecuteReader();

            List<string> patientListe = new List<string>();

            //Undersøg
            while(rdr.Read())
            {
               
                patientListe.Add(rdr["Navn"].ToString());

            }

            // Lukke
            connpatient.Close();
            return patientListe;
        }

        public int getCPR(string valgtPatient)
        {
            int cprResultat = 0;
            cmd = new SqlCommand("select CPR from Patient where Navn'" + valgtPatient + "'", connpatient);
            connpatient.Open();
            rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                cprResultat = rdr.GetInt32(0);
            }

            connpatient.Close();
            return cprResultat;
        }

        public int getKode(string brugernavn)
        {
            int kodeResultat = 0;
            cmd = new SqlCommand("select Adgangskode from Personale where Brugernavn ='" + brugernavn + "'", connpersonale);
            connpersonale.Open();
            rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                kodeResultat = rdr.GetInt32(0);
            }

            connpersonale.Close();
            return kodeResultat;
        }

        public void GemBTData()
        {
            // epj database
        }

        public void GemPuls()
        {

        }

       public void HentEKGdata()
        {

        }

    }
}
