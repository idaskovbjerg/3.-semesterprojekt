﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.DTOlag
{
    public class PatientDTO
    {
        public string PatientNavn { get; set; }
        public long CPR { get; set; }

        public PatientDTO()
        {
        }

        public PatientDTO(string patientNavn, long cpr)
        {
            PatientNavn = patientNavn;
            CPR = cpr;
        }
    }
}