﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
//using System.Data;
using PulsMaalerSystem;
using PulsMaalerSystem.DTOlag;
using System.Threading;
using System.Collections;



namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag : ISubject, IObserver
    {
        Digitalt_filter digi;
        DataLag data;
        Blodtryk blodtryk;
        ST3DAQ voresdaq;
        private List<IObserver> observers = null;
        private List<double> BTmålinger;
        private List<double> graftilGUIMålinger;
        private List<double> Blodtryksværdiliste;
        private double kalibreringstal;

        //Overvej om forskellen mellem dia eller sys grænseværdier skal gemmes i 

        GrænseVærdiDTO diastoleGrænseVærdi;
        GrænseVærdiDTO systoleGrænseVærdi;

        
        
        Thread tlogik;


        public LogikLag()
        {
            blodtryk = new Blodtryk();
            data = new DataLag();
            voresdaq = new ST3DAQ();
            observers = new List<IObserver>();
            digi = new Digitalt_filter();
            BTmålinger = new List<double>();
            graftilGUIMålinger = new List<double>();
            kalibreringstal = 1;
            Blodtryksværdiliste = new List<double>();

            systoleGrænseVærdi = new GrænseVærdiDTO(100, 140);
            diastoleGrænseVærdi = new GrænseVærdiDTO(60, 90);
 

            for (int i = 0; i < 1000; i++)
            {
                graftilGUIMålinger.Add(0.0);
            }

            //Notify(graftilGUIMålinger); //laver tom liste (nu array)

            tlogik = new Thread(StartHentData);

        }

        public void SetFilterOn()
        {
            digi.SetFilterOn();
            
        }

        public void SetFilterOff()
        {
            digi.SetFilterOff();
        }

        public bool IsFilterOn()
        {
            return digi.IsFilterOn();
        }

        public void setKalibreringstal(double tal)
        {
            kalibreringstal = tal;
        }

        

        public void hentBTdata(string port, double min, double max, double rate, int sample) // henter det grimme
        {
            voresdaq.startReadData(port, min, max, rate, sample);
            tlogik.Start();
            
        }

       

        private void StartHentData()
        {
            int rådatatæller = 0;
            int køTæller = 0;

            Queue<double> myQ = new Queue<double>(500);
            voresdaq.Attach(this);
          
            //myQ.Clear();

            while (isRunning())
            {
                if (Blodtryksværdiliste.Count > 0) // && Blodtryksværdiliste.Count < rådatatæller)
                {
                    for (int i = 0; i < 499 && rådatatæller <= Blodtryksværdiliste.Count; i++)
                    {
                        if (køTæller == 499)
                        {
                            double værdi = 0.0;

                            if(rådatatæller == 0)
                            {
                                 værdi = Blodtryksværdiliste[0];
                            }
                            else
                            {
                                værdi = Blodtryksværdiliste[rådatatæller-1];
                            }
                            
                            myQ.Dequeue();
                            myQ.Enqueue(værdi);
                            rådatatæller++;
                        }
                        else
                        {
                            double værdi = 0.0;

                            if (rådatatæller == 0)
                            {
                                værdi = Blodtryksværdiliste[0];
                            }
                            else
                            {
                                værdi = Blodtryksværdiliste[rådatatæller - 1];
                            }
                            
                            
                            myQ.Enqueue(værdi);
                            køTæller++;
                            rådatatæller++;
                        }       
                    }

                    rådatatæller--;

                    double[] indenfilter = myQ.ToArray();

                    if (digi.IsFilterOn())
                    {
                        digi.FilterMovingAverage(10, indenfilter);
                    }

                    Notify(indenfilter.ToArray());
                }
                
            }
        }

      
        //public List<double> hentEKGdata()
        //{
        //    return data.hentEKGdata();
        //}
        public bool getKode(string brugernavn, int kode)
        {
            return (kode.Equals(data.getKode(brugernavn)));

        }
        public string getCPR(string cpr, string valgtNavn)
        {
            return cpr; 
        }
        public bool isRunning()
        {
            return voresdaq.IsRunning();
        }
        public void StopHentData()
        {
            voresdaq.Detach(this);
            voresdaq.StopReadData();
            tlogik.Abort();
        }
      
        public List<string> listePatient(string brugernavn)
        {
            return data.PatientOpslag(brugernavn);
        }


        public bool TjekSystoleOverskredet(List<double> blodtryksListe)
        {
            List<int> systoler = blodtryk.BeregnSystole(blodtryksListe);
            bool grænseværdioverskredet = false;

            foreach (int systole in systoler)
            {

                if (systoleværdi > grænseVærdiSysØvre || systoleværdi < grænseVærdiSysNedre)
                {
                    grænseværdioverskredet = true;
                }

                else grænseværdioverskredet = false;
            }

            return grænseværdioverskredet;
        }
        
        public bool TjekDiastoleOverskredet(List<double> blodtryksListe)
        {
            List<int> diastoler = blodtryk.BeregnDiastole(blodtryksListe);

            bool grænseværdioverskredet = false;

            foreach(int diastole in diastoler)
            { 
                if (diastole > grænseVærdiDiaØvre || diastole < grænseVærdiDiaNedre)
                {
                    grænseværdioverskredet = true;
                }
                else grænseværdioverskredet = false;
            }

            return grænseværdioverskredet;
        }
     
        public List<int> SystoleListe(List<double> blodtryksListe)
        {
            return blodtryk.BeregnSystole(blodtryksListe);
       
        }
       
        

        public List<int> DiastoleListe(List<double> blodtryksListe)
        {
            return blodtryk.BeregnDiastole(blodtryksListe);
        }

        public List<int> Middeltrykliste(List<int> systoleliste, List<int> diastoleliste, List<double> blodtryksListe)
        {
           return blodtryk.BeregnMiddeltryk(systoleliste, diastoleliste, blodtryksListe);
        }
                       
        public void BeregnEKG(int puls)
        {

        }

        public void UdsaetAlarm()
        {

        }

        public void StopLyd()
        {

        }

        public void HentEKGdata()
        {
            //port,min,max,rate, sample ????
        }

     
        public GrænseVærdiDTO SystoleOP()
        {
            int nedre = systoleGrænseVærdi.NedreGrænseVærdi;
            nedre++;
            int øvre = systoleGrænseVærdi.ØvreGrænseVærdi;
            øvre++;

            systoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return systoleGrænseVærdi;
        }
        public GrænseVærdiDTO SystoleNED()
        {
            int nedre = systoleGrænseVærdi.NedreGrænseVærdi;
            nedre--;
            int øvre = systoleGrænseVærdi.ØvreGrænseVærdi;
            øvre--;

            systoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return systoleGrænseVærdi;
        }
        public GrænseVærdiDTO DiastoleOP()
        {
            int nedre = diastoleGrænseVærdi.NedreGrænseVærdi;
            nedre++;
            int øvre = diastoleGrænseVærdi.ØvreGrænseVærdi;
            øvre++;

            diastoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return diastoleGrænseVærdi;
        }
        public GrænseVærdiDTO DiastoleNED()
        {
            int nedre = diastoleGrænseVærdi.NedreGrænseVærdi;
            nedre--;
            int øvre = diastoleGrænseVærdi.ØvreGrænseVærdi;
            øvre--;

            diastoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return diastoleGrænseVærdi;
        }

        public GrænseVærdiDTO HentSystoleGrænseværdier()
        {
            return systoleGrænseVærdi;
        }

        public GrænseVærdiDTO HentDiastoleGrænseværdier()
        {
            return diastoleGrænseVærdi;
        }

        public void NulpunktsJustering()
        {
            
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify(double[] graftilGUIMålinger)
        {
            foreach (IObserver obs in observers)
            {
                obs.Update(graftilGUIMålinger);
            }
        }

        public void Update(double[] graf)
        {
            Blodtryksværdiliste.AddRange(graf);
        }
    }
}