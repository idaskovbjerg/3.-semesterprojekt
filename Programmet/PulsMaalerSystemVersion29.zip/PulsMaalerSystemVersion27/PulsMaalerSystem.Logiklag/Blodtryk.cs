﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;

namespace PulsMaalerSystem.Logiklag
{
    class Blodtryk
    {
        private const int grænseværdiSys = 100;
        private const int grænseværdiDia = 90;
     
        public Blodtryk()
        {
                                    
        }

        public List<int> BeregnSystole(List<double> blodtryksliste)
        {
            double baseline = 110;
            double maxTrykOverBaseline = baseline;
            
            double baselineoverskredet = 0;
            List<int> toppunkter = new List<int>();

            for (int i = 0; i < blodtryksliste.Count - 1; i++)
            {
                if (blodtryksliste[i] > maxTrykOverBaseline)
                {
                    maxTrykOverBaseline = blodtryksliste[i];
                    baselineoverskredet++;
                }
                else
                {
                    if (blodtryksliste[i] < maxTrykOverBaseline && baselineoverskredet > 0)
                    {
                        toppunkter.Add(Math.Abs(Convert.ToInt32(blodtryksliste[i - 1])));
                        baselineoverskredet = 0;
                        maxTrykOverBaseline = baseline;
                        i = i + 50;
                    }
                }

            }
            
            return toppunkter; 
        }

        /*public int BeregnPuls(List<double> blodtryksliste)
        {
            List<int> toppunkter = BeregnSystole(blodtryksliste);

            int samplesPrSekund = toppunkter.Count * 10;

            return toppunkter.Count;
        }*/

        public List<int> BeregnDiastole(List<double> blodtryksliste)
        {
            double baseline = 60;
            double maxTrykOverBaseline = baseline;

            double baselineoverskredet = 0.0;
            List<int> minimumspunkter = new List<int>();

            for (int i = 0; i < blodtryksliste.Count - 1; i++)
            {
                if (blodtryksliste[i] < maxTrykOverBaseline)
                {
                    maxTrykOverBaseline = blodtryksliste[i];
                    baselineoverskredet++;
                }
                else
                {
                    if (blodtryksliste[i] > maxTrykOverBaseline && baselineoverskredet > 0)
                    {
                        minimumspunkter.Add(Math.Abs(Convert.ToInt32(blodtryksliste[i - 1])));
                        baselineoverskredet = 0;
                        maxTrykOverBaseline = baseline;
                        i = i + 50;
                    }
                }

            }

            return minimumspunkter;
        }

        public List<int> BeregnMiddeltryk(List<int> systoleliste, List<int> diastoleliste, List<double> blodtryksliste)
        {
            int middeltryk;
            List<int> middeltrykliste = new List<int>();
            for (int i = 0; (i < diastoleliste.Count && i < systoleliste.Count); i++)
            {
               middeltryk = Math.Abs(((2 * diastoleliste[i]) / 3) + ((1 * systoleliste[i]) / 3));
               middeltrykliste.Add(middeltryk);

           }
           return middeltrykliste;
        }
    }
}
