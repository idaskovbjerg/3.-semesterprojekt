﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.Logiklag
{
    public class Nulpunkts_justering
    {
        public void NulpunktsJustering()
        {

        }

        public double NulpunktsJuster(double nulpunktværdi)
        {
            double n;

            n = 0 - (nulpunktværdi);

            return n;
        }
    }
}