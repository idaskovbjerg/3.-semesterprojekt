﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using System.Threading;
using PulsMaalerSystem.DTOlag;

namespace PulsMaalerSystem
{
    public partial class HovedGUI : Form, IObserver
    {
        LogikLag logik;
        Digitalt_filter digi;
        TimeSpan tidTæller;
        private string brugernavn;
        public string port = "";
        double max = 5;
        double min = -5;
        double rate = 1000;
        int sample = 1000;       
        double[] Blodtrykliste;
        int grænseværdiSysOp;
        int grænseværdiSysNed;
        int grænseværdiDiaOp;
        int grænseværdiDiaNed;
        int dianedværdi = 60;
        int diaopværdi = 90;
        int sysnedværdi = 100;
        int sysopværdi = 140;
      

        public HovedGUI(string brugernavn)
        {
            InitializeComponent();

            Blodtrykliste = new double[500];

            tidTextBox.ForeColor = tidTextBox.ForeColor;
            tidTextBox.BackColor = tidTextBox.BackColor;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTextBox.ReadOnly  = true;
            grænseværdiSysOp = 140;
            grænseværdiSysNed = 100;
            grænseværdiDiaOp = 90;
            grænseværdiDiaNed = 60;
    
        
            this.brugernavn = brugernavn;
            logik = new LogikLag();
            tidTæller = new TimeSpan();
            digi = new Digitalt_filter();

            //hent systole / dia øvre og nedre

            
            
            
        }



 

        private delegate void UpdateUICallback();

        private void updateChart()
        {
            if(Blodtryk.InvokeRequired)
            {
                this.Invoke(new UpdateUICallback(updateChart));
                return;
            }

            if(Blodtrykliste.Length >= 498)
            {
                Blodtryk.Series["Arterietryk"].Points.Clear();
                Blodtryk.Series["Arterietryk"].Points.DataBindY(Blodtrykliste);

                Blodtryk.Invalidate();                
            }
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            tidTextBox.Text = tidTæller.ToString();
            tidTextBox.ForeColor = Color.White;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTæller += new TimeSpan(0, 0, 1);
        }

        private void tandKnap_Click(object sender, EventArgs e) 
        {
            logik.hentBTdata(port, min, max, rate, sample);
            tidTæller = new TimeSpan();
            timer1.Start();

            tandKnap.Enabled = false;
            slukKnap.Enabled = true;
            filterOff.Enabled = true;
            nulpunktKnap.Enabled = true;
            button1.Enabled = true;
            button1.Visible = true;

            logik.Attach(this);

            sysOpLabel.Text = logik.HentSystoleGrænseværdier().ØvreGrænseVærdi.ToString();
            sysNedLabel.Text = logik.HentSystoleGrænseværdier().NedreGrænseVærdi.ToString();

            diaOpLabel.Text = logik.HentDiastoleGrænseværdier().ØvreGrænseVærdi.ToString();
            diaNedLabel.Text = logik.HentDiastoleGrænseværdier().NedreGrænseVærdi.ToString();
        }

        private void slukKnap_Click(object sender, EventArgs e)
        {
            slukKnap.Enabled = false;
            tandKnap.Enabled = true;
            afbrydKnap.Enabled = true;
            nulpunktKnap.Enabled = false;

            timer1.Stop();
            logik.StopHentData();
            logik.Detach(this);
           
        }

        private void filterOff_Click(object sender, EventArgs e)
        {

            if (filterOff.Text.Equals("ON"))
            {
                filterOff.Text = "OFF";
                digi.DigiFilterOff();
            }

            else
            {
                filterOff.Text = "ON";
                digi.DigiFilterOn();
            }
        }

        private void afbrydKnap_Click(object sender, EventArgs e)
        {
            StartGUI Startskærm = new StartGUI();

            if(MessageBox.Show("Er du sikker?","Bekræft",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Startskærm.Show();
                this.Hide();
            }
           
            
        }

        private void nulpunktKnap_Click(object sender, EventArgs e)
        {
            //updateChart()
        }


        private void Alarm()
        {
            Console.Beep(500, 6000);// duration skal ændres til at være så længe grænseværdien er overskredet 
            // skal også update visbtdata
        }

        private void alarmKnap_Click(object sender, EventArgs e)
        {

        }

        private void VisBTdata()
        {

        }

        private void VisPuls()
        {

        }

        private void systoleOP_Click(object sender, EventArgs e)
        {
            sysOpLabel.Text = logik.SystoleOP().ØvreGrænseVærdi.ToString();          
        }
        
        private void diastoleNED_Click(object sender, EventArgs e)
        {
            diaNedLabel.Text = logik.DiastoleNED().NedreGrænseVærdi.ToString(); 
        }

        private void diastoleOP_Click(object sender, EventArgs e)
        {
            diaOpLabel.Text = logik.DiastoleOP().ØvreGrænseVærdi.ToString();
        }

        private void systoleNED_Click(object sender, EventArgs e)
        {
            sysNedLabel.Text = logik.SystoleNED().NedreGrænseVærdi.ToString();   
        }



        public void Update(double[] graf)
        {
            Blodtrykliste = graf;
            updateChart();
        }
    }


}
