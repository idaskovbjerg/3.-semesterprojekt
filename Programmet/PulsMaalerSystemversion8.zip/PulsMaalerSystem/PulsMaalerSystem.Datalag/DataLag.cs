﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PulsMaalerSystem.Datalag
{
    public class DataLag
    {

        private SqlConnection conn;
        private SqlDataReader rdr;
        private SqlCommand cmd;
        private const String db = "F15ST2ITS2201404669"; // Tilrettes DB
        private ST3DAQ voresDaq;

        public DataLag()
        {
            // Opsætning af DB forbindelsen til SQL Server webhotel10.iha.dk og valgt database (db)
            conn = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + db + ";Persist Security Info=True;User ID=" + db + ";Password=" + db + "");
            voresDaq = new ST3DAQ();
        }


        public bool isRunning()
        {
            return voresDaq.IsRunning();
        }

        public void StopHentData()
        {
            voresDaq.StopReadData();
        }


        public List<double> blodtrykVaerdi()
        {
            return voresDaq.blodtrykData;
        }


        public List<double> hentBTdata(string port, double min, double max, double rate, int sample)
        {


            voresDaq.startReadData(port, min, max, rate, sample);

            return new List<double>();
        }
           
      
        public int  BrugernavnOpslag(string brugernavn)
        {
            int brugerResultat = 0;

            // Oprette
            cmd = new SqlCommand("select * from Personale where Brugernavn ='" + brugernavn + "'", conn);

            conn.Open();

            // Udføre 
            rdr = cmd.ExecuteReader();

            // Undersøge
            if (rdr.Read())
            {
                if (Convert.ToBoolean(rdr["Brugernavn"]))  // her udvælges kolonnen i resultattabellen med rdr[1], som converteres fra SQL-typen bit til C# typen boolean
                    brugerResultat = 1; // Brugernavn er OK og registreret
                else
                    brugerResultat = 2; // Brugernavn er ikke OK
            }

            // Lukke
            conn.Close();
            return brugerResultat;
        }

        public List<string> PatientOpslag(string brugernavn)
        {
            
            cmd = new SqlCommand("select * from Patient where Sundhedsfaglig_personale ='" + brugernavn + "'", conn);
            conn.Open();
            rdr = cmd.ExecuteReader();

            List<string> patientListe = new List<string>();

            //Undersøg
            while(rdr.Read())
            {
               
                patientListe.Add(rdr["Navn"].ToString());

            }

            // Lukke
            conn.Close();
            return patientListe;
        }

        public int getCPR(string valgtPatient)
        {
            int cprResultat = 0;
            cmd = new SqlCommand("select CPR from Patient where Navn'" + valgtPatient + "'", conn);
            conn.Open();
            rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                cprResultat = rdr.GetInt32(0);
            }

            conn.Close();
            return cprResultat;
        }

        public int getKode(string brugernavn)
        {
            int kodeResultat = 0;
            cmd = new SqlCommand("select Adgangskode from Personale where Brugernavn ='" + brugernavn + "'", conn);
            conn.Open();
            rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                kodeResultat = rdr.GetInt32(0);
            }

            conn.Close();
            return kodeResultat;
        }

    }
}
