﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;



namespace PulsMaalerSystem
{
    public partial class StartGUI : Form
    {
        private LogikLag logik;
        private HovedGUI hovedskærm;

        public StartGUI()
        {
            InitializeComponent();
            logik = new LogikLag();
            //passwordTextBox.PasswordChar = '*';
            
        }

        private void tjekBruger(string brugernavn, int kode)
        {
            patientComboBox.Enabled = false;
            if (logik.getKode(brugernavn, kode))
            {
                hovedskærm = new HovedGUI(brugernavn);
                patientComboBox.Enabled = true;
                label6.Text = "Logget på";
            }

            else
            {
                label6.Text = "Brugernavn og/eller kode indtastet forkert";
                patientComboBox.Enabled = false;
            }

        }
        


        private void opsætningKnap_SelectedIndexChanged(object sender, EventArgs e)
        {
            idTextBox.Enabled = true;
            passwordTextBox.Enabled = true;
            loginKnap.Enabled = true;
        }

        public void tjekPatient(string brugernavn)
        {
            foreach (var patienter in logik.listePatient(idTextBox.Text))
            {
                patientComboBox.Items.Add(patienter);
            }
        }
        private void loginKnap_Click(object sender, EventArgs e)
        {
            tjekBruger(idTextBox.Text, Convert.ToInt32(passwordTextBox.Text));
            patientComboBox.Items.Clear();
            tjekPatient(idTextBox.Text);
        }

        //public string valgtPatient()
        //{
            
        //    return logik.getCPR(,patientComboBox.SelectedItem.ToString());
        //}
        
        private void patientComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            hovedskærm.port = opsætningKnap.SelectedItem.ToString();
            hovedskærm.Show();
            this.Hide();
        }

        


        
    }
}
