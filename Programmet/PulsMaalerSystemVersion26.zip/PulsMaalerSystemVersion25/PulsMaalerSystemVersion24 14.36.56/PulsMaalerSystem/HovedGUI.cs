﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using System.Threading;
using PulsMaalerSystem.DTOlag;
using System.Media;

namespace PulsMaalerSystem
{
    public partial class HovedGUI : Form, IObserver
    {
        LogikLag logik;
        Nulpunkts_justering nulpunktjustering;
        
        TimeSpan tidTæller;
        private string brugernavn;
        public string port = "";
        double max = 5;
        double min = -5;
        double rate = 1000;
        int sample = 100;       
        double[] Blodtrykliste;
        public PatientDTO patient = new PatientDTO();
        
        //Brian test af timers
        System.Timers.Timer alarmTimer = new System.Timers.Timer();
        System.Timers.Timer tidsTimer = new System.Timers.Timer();
        //private SoundPlayer alarmPlayer;
        //Billeder til alarm test
        Bitmap redAlarm = new Bitmap(@"\\psf\Home\Desktop\PulsMaalerSystemVersion25\PulsMaalerSystemVersion24 14.36.56\PulsMaalerSystem\Resources\AlarmknapRed.jpg");
        Bitmap whiteAlarm = new Bitmap(@"\\psf\Home\Desktop\PulsMaalerSystemVersion25\PulsMaalerSystemVersion24 14.36.56\PulsMaalerSystem\Resources\AlarmknapWhite.jpg");

        bool postPoneSoundAlarm;
        TimeSpan alarmPostponeDuration;
        DateTime alarmResumeTime;

        public HovedGUI(string brugernavn, LogikLag logik)
        {
            InitializeComponent();

            Blodtrykliste = new double[500];

            tidTextBox.ForeColor = tidTextBox.ForeColor;
            tidTextBox.BackColor = tidTextBox.BackColor;
            tidTextBox.TextAlign = HorizontalAlignment.Center;
            tidTextBox.ReadOnly = true;

            this.brugernavn = brugernavn;
            this.logik = logik;
            tidTæller = new TimeSpan();
            nulpunktjustering = new Nulpunkts_justering();
            //hent systole / dia øvre og nedre

            /*
             Brian tester herunder
             */

            //alarmPlayer = new SoundPlayer();

            //Brian test af tidstimer
            tidsTimer.Elapsed += tidsTæller_Elapsed;
            tidsTimer.Interval += 1000;

            //Brian test af alarmtimer
            alarmTimer.Elapsed += alarmTimer_Elapsed;
            alarmTimer.Interval = 1000;
            alarmKnap.BackgroundImage = whiteAlarm;

            alarmPostponeDuration = new TimeSpan(6000);

            postPoneSoundAlarm = false;
            radioButtonON.Checked = true;
            if (radioButtonON.Checked == true)
            {
                logik.SetFilterOn();
            }
            else
            {
                logik.SetFilterOff();
            }
        }

        void tidsTæller_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            MethodInvoker action = delegate
            {
                tidTæller += new TimeSpan(0, 0, 1);
                tidTextBox.Text = tidTæller.ToString();
                tidTextBox.ForeColor = Color.White;
                tidTextBox.TextAlign = HorizontalAlignment.Center;
            };

            tidTextBox.BeginInvoke(action);
        }

        //Mere test af alarmtimer - Brian
        void alarmTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            MethodInvoker action = delegate
            {
                if (logik.TjekDiastoleOverskredet(Blodtrykliste.ToList()))
                {
                    if (alarmKnap.BackgroundImage == whiteAlarm)
                    {
                        alarmKnap.BackgroundImage = redAlarm;

                        if (!postPoneSoundAlarm)
                        {
                            SystemSounds.Beep.Play();
                        }
                        else
                        {
                            if (DateTime.Now > alarmResumeTime)
                            {
                                postPoneSoundAlarm = false;
                            }
                        }
                    }
                    else
                    {
                        alarmKnap.BackgroundImage = whiteAlarm;
                    }
                    
                }
                else if (logik.TjekSystoleOverskredet(Blodtrykliste.ToList()))
                {
                    if (alarmKnap.BackgroundImage == whiteAlarm)
                    {
                        alarmKnap.BackgroundImage = redAlarm;

                        if (!postPoneSoundAlarm)
                        {
                            SystemSounds.Beep.Play();
                        }
                        else
                        {
                            if (DateTime.Now < alarmResumeTime)
                            {
                                postPoneSoundAlarm = false;
                            }
                        }
                    }
                    else
                    {
                        alarmKnap.BackgroundImage = whiteAlarm;
                    }
                }
            };

            alarmKnap.BeginInvoke(action);
        }

        private delegate void UpdateUICallback();

        private void updateChart()
        {
            if(Blodtryk.InvokeRequired)
            {
                this.Invoke(new UpdateUICallback(updateChart));
                return;
            }

            if(Blodtrykliste.Length >= 498)
            {
                Blodtryk.Series["Arterietryk"].Points.Clear();
                Blodtryk.Series["Arterietryk"].Points.DataBindY(Blodtrykliste);
               
                List<int> systolelisterne = logik.SystoleListe(Blodtrykliste.ToList());

                if (systolelisterne.Count == 0)
                {
                    sysLabel.Text = "-";
                }
                else
                {
                    sysLabel.Text = systolelisterne[systolelisterne.Count - 1].ToString();
                }

                List<int> diastoleliste = logik.DiastoleListe(Blodtrykliste.ToList());
                if (diastoleliste.Count == 0)
                {
                    diaLabel.Text = "-";
                }
                else
                {
                    diaLabel.Text = diastoleliste[diastoleliste.Count - 1].ToString();
                }

                List<int> middeltryksliste = logik.Middeltrykliste(systolelisterne, diastoleliste, Blodtrykliste.ToList());
                if (middeltryksliste.Count == 0)
                {
                    middelLabel.Text = "(--)";
                }
                else
                {
                    middelLabel.Text = "("+middeltryksliste[middeltryksliste.Count - 1].ToString()+")";
                }

                Blodtryk.Invalidate();

                //Her skal også tjekkes på alarm systoler
            }
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
        }

        private void tandKnap_Click(object sender, EventArgs e) 
        {
            logik.hentBTdata(port, min, max, rate, sample, patient);

            alarmTimer.Enabled = true;
            tidsTimer.Enabled = true;
            slukKnap.Enabled = true;
            nulpunktKnap.Enabled = false;
            
            logik.Attach(this);

            sysOpLabel.Text = logik.HentSystoleGrænseværdier().ØvreGrænseVærdi.ToString();
            sysNedLabel.Text = logik.HentSystoleGrænseværdier().NedreGrænseVærdi.ToString();

            diaOpLabel.Text = logik.HentDiastoleGrænseværdier().ØvreGrænseVærdi.ToString();
            diaNedLabel.Text = logik.HentDiastoleGrænseværdier().NedreGrænseVærdi.ToString();

            tandKnap.Enabled = false;
        }

        private void slukKnap_Click(object sender, EventArgs e)
        {
            alarmTimer.Enabled = false;
            tidsTimer.Enabled = false;

            slukKnap.Enabled = false;
            tandKnap.Enabled = true;
            afbrydKnap.Enabled = true;
            nulpunktKnap.Enabled = false;

            logik.StopHentData();
            logik.Detach(this);
           
        }

        
        private void afbrydKnap_Click(object sender, EventArgs e)
        {
            StartGUI Startskærm = new StartGUI();

            if(MessageBox.Show("Er du sikker?","Bekræft",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Startskærm.Show();
                this.Hide();
            }    
        }

        private void nulpunktKnap_Click(object sender, EventArgs e)
        {
            //updateChart()
            tandKnap.Enabled = true;

            double nulpunktværdi;
            nulpunktværdi = nulpunktjustering.NulpunktsJuster(Convert.ToDouble(npj_værdi_textBox.Text));
            logik.setNulpunktsJustering(nulpunktværdi);
            tandKnap.Enabled = true;
        }


        private void alarmKnap_Click(object sender, EventArgs e)
        {
            postPoneSoundAlarm = true;
            alarmResumeTime = DateTime.Now.Add(alarmPostponeDuration);
        }

        private void VisBTdata()
        {

        }

        private void VisPuls()
        {

        }

        private void systoleOP_Click(object sender, EventArgs e)
        {
            GrænseVærdiDTO nyeVærdier = logik.SystoleOP();   
            sysOpLabel.Text = nyeVærdier.ØvreGrænseVærdi.ToString();
            sysNedLabel.Text = nyeVærdier.NedreGrænseVærdi.ToString();
        }
        
        private void diastoleNED_Click(object sender, EventArgs e)
        {
            GrænseVærdiDTO nyeVærdier = logik.DiastoleNED();
            diaOpLabel.Text = nyeVærdier.ØvreGrænseVærdi.ToString();
            diaNedLabel.Text = nyeVærdier.NedreGrænseVærdi.ToString();
        }

        private void diastoleOP_Click(object sender, EventArgs e)
        {
            GrænseVærdiDTO nyeVærdier = logik.DiastoleOP();
            diaOpLabel.Text = nyeVærdier.ØvreGrænseVærdi.ToString();
            diaNedLabel.Text = nyeVærdier.NedreGrænseVærdi.ToString();
        }

        private void systoleNED_Click(object sender, EventArgs e)
        {
            GrænseVærdiDTO nyeVærdier = logik.SystoleNED();
            sysOpLabel.Text = nyeVærdier.ØvreGrænseVærdi.ToString();
            sysNedLabel.Text = nyeVærdier.NedreGrænseVærdi.ToString();  
        }

        public void Update(double[] graf)
        {
            Blodtrykliste = graf;
            updateChart();
        }

        private void HovedGUI_Load(object sender, EventArgs e)
        {
            navnLabel.Text = "Navn: " + patient.PatientNavn;
            CPRlabel.Text = "CPR: " + patient.CPR;
        }

        
    }
}
