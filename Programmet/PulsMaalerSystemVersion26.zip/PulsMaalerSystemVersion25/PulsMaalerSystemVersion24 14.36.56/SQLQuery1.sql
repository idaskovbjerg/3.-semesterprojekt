﻿CREATE TABLE [db_owner].[Patient] (
    [CPR]                      NVARCHAR (10) NOT NULL,
    [Navn]                     NVARCHAR (50) NOT NULL,
    [Sundhedsfaglig_personale] NVARCHAR (4)  NULL,
    PRIMARY KEY CLUSTERED ([CPR] ASC)
);