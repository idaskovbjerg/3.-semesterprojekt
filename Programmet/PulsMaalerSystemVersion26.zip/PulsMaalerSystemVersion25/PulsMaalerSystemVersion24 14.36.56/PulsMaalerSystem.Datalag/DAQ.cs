﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using NationalInstruments.DAQmx;
using NationalInstruments;
using System.Collections.Generic;
using PulsMaalerSystem.DTOlag;

namespace PulsMaalerSystem.Datalag
{
    public class ST3DAQ : ISubject
    {
        private AnalogMultiChannelReader analogInReader;
        private Task myTask;
        private Task runningTask;
        private AsyncCallback analogCallback;

        private AnalogWaveform<double>[] data;
        private int samplesPrChannel;
        private List<IObserver> observers;

        public ST3DAQ()
        {
            observers = new List<IObserver>();
        }

        public bool IsRunning()
        {
            if (runningTask != null)
            {
                return true;
            }
            else { return false; }
        }

        public void startReadData(string readPort, double minValue, double maxValue, double rate, int samples)
        {
            if (runningTask == null)
            {
                try
                {
                    samplesPrChannel = samples;

                    // Create a new task
                    myTask = new Task();

                    // Create a virtual channel
                    myTask.AIChannels.CreateVoltageChannel(readPort, "",
                        (AITerminalConfiguration)(-1), minValue,
                        maxValue, AIVoltageUnits.Volts);


                    // Configure the timing parameters
                    myTask.Timing.ConfigureSampleClock("", rate,
                        SampleClockActiveEdge.Rising, SampleQuantityMode.ContinuousSamples, samplesPrChannel);

                    // Verify the Task
                    myTask.Control(TaskAction.Verify);

                    runningTask = myTask;
                    analogInReader = new AnalogMultiChannelReader(myTask.Stream);
                    analogCallback = new AsyncCallback(AnalogInCallback);

                    // Use SynchronizeCallbacks to specify that the object
                    // marshals callbacks across threads appropriately.
                    analogInReader.SynchronizeCallbacks = true;
                    analogInReader.BeginReadWaveform(samples, analogCallback, myTask);
                }
                catch (DaqException exception)
                {
                    runningTask = null;
                    myTask.Dispose();
                }
            }
        }

        private void AnalogInCallback(IAsyncResult ar)
        {
            try
            {
                if (runningTask != null && runningTask == ar.AsyncState)
                {
                    // Read the available data from the channels
                    data = analogInReader.EndReadWaveform(ar);

                    List<double> notifyData = new List<double>();

                    for (int sample = 0; sample < data[0].Samples.Count; ++sample)
                    {
                        notifyData.Add(data[0].Samples[sample].Value);
                        //dataTable.Rows[sample][currentLineIndex] = ;
                    }

                    Notify(notifyData.ToArray());
                    
                    analogInReader.BeginMemoryOptimizedReadWaveform(samplesPrChannel,
                        analogCallback, myTask, data);
                }
            }
            catch (DaqException exception)
            {
                // Display Errors
                runningTask = null;
                myTask.Dispose();

                //throw exception;
            }
        }

        public void StopReadData()
        {
            if (runningTask != null)
            {
                // Dispose of the task
                runningTask = null;
                myTask.Dispose();
            }
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify(double[] graftilGUIMålinger)
        {
            foreach (IObserver obs in observers)
            {
                obs.Update(graftilGUIMålinger);
            }
        }
    }
}