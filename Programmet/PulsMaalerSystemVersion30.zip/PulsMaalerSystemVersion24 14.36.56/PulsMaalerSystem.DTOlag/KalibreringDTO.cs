﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.DTOlag
{
    public class KalibreringDTO
    {
        public double Volt_ { get; set; }
        public int Pressure_mmhg_ { get; set; }

        public KalibreringDTO(double volt, int mmhg)
        {
            Pressure_mmhg_ = mmhg;
            Volt_ = volt;
        }
    }
}