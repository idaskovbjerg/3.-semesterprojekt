﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
using PulsMaalerSystem;
using PulsMaalerSystem.DTOlag;
using System.Threading;
using System.Collections;
using System.Configuration;

namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag : ISubject, IObserver
    {
        Digitalt_filter digi;
        DataLag data;
        Blodtryk blodtryk;
        ST3DAQ voresdaq;
        private List<IObserver> observers = null;
        private List<double> BTDataTilDB;
        private List<double> graftilGUIMålinger;
        private List<double> Blodtryksværdiliste;
        private double kalibreringstal;
        private double nulpunkt;
        private PatientDTO Patient;

        //Grænseværdier
        GrænseVærdiDTO diastoleGrænseVærdi;
        GrænseVærdiDTO systoleGrænseVærdi;       
        
        Thread tlogik;

        public LogikLag()
        {
            blodtryk = new Blodtryk();
            data = new DataLag();
            voresdaq = new ST3DAQ();
            observers = new List<IObserver>();
            digi = new Digitalt_filter();
            BTDataTilDB = new List<double>();
            graftilGUIMålinger = new List<double>();
            kalibreringstal = Convert.ToDouble(ConfigurationManager.AppSettings["KalibreringsKoefficient"]);
            nulpunkt = 0;
            Blodtryksværdiliste = new List<double>();

            systoleGrænseVærdi = new GrænseVærdiDTO(100, 140);
            diastoleGrænseVærdi = new GrænseVærdiDTO(60, 90);
        }

        public void SetFilterOn()
        {
            digi.SetFilterOn();
        }

        public void SetFilterOff()
        {
            digi.SetFilterOff();
        }

        public bool IsFilterOn()
        {
            return digi.IsFilterOn();
        }

        public void setKalibreringstal(double tal)
        {
            
            kalibreringstal = tal;
        }

        public void hentBTdata(string port, double min, double max, double rate, int sample, PatientDTO patient) // henter det grimme
        {
            Patient = patient;
            voresdaq.startReadData(port, min, max, rate, sample);
            tlogik = new Thread(StartHentData);
            tlogik.Start();
        }

        private void StartHentData()
        {
            int rådatatæller = 0;
            int køTæller = 0;

            Queue<double> myQ = new Queue<double>(500);
            voresdaq.Attach(this);

            while (isRunning())
            {
                if (Blodtryksværdiliste.Count > 0)
                {
                    for (int i = 0; i < 499 && rådatatæller <= Blodtryksværdiliste.Count; i++)
                    {
                        if (køTæller == 499)
                        {
                            double værdi = 0.0;

                            if(rådatatæller == 0)
                            {
                                 værdi = Blodtryksværdiliste[0];
                            }
                            else
                            {
                                værdi = Blodtryksværdiliste[rådatatæller-1];
                            }
                            
                            myQ.Dequeue();
                            værdi += nulpunkt;
                            værdi = værdi * kalibreringstal;
                            myQ.Enqueue(værdi);
                            rådatatæller += 10;
                        }
                        else
                        {
                            double værdi = 0.0;

                            if (rådatatæller == 0)
                            {
                                værdi = Blodtryksværdiliste[0];
                            }
                            else
                            {
                                værdi = Blodtryksværdiliste[rådatatæller - 1];
                            }
                            værdi += nulpunkt;
                            værdi = værdi * kalibreringstal;
                            myQ.Enqueue(værdi);
                            køTæller++;
                            rådatatæller += 10;
                        }       
                    }

                    rådatatæller--;

                    double[] indenfilter = myQ.ToArray();

                    if (digi.IsFilterOn())
                    {
                        indenfilter = digi.FilterMovingAverage(5, indenfilter);
                    }

                    Notify(indenfilter);
                }
            }
        }

        //Unittest - 09-12-2015 - Brian
        public bool getKode(string brugernavn, int kode)
        {
            return (kode.Equals(data.getKode(brugernavn)));
        }

        //Unittest - 09-12-2015 - Brian
        public bool isRunning()
        {
            return voresdaq.IsRunning();
        }
        
        public void StopHentData()
        {
            voresdaq.Detach(this);
            voresdaq.StopReadData();
            tlogik.Abort();
        }

        //Unittest - 09-12-2015 - Brian
        public List<PatientDTO> listePatient(string brugernavn)
        {
            return data.PatientOpslag(brugernavn);
        }

        //Fremtidigt arbejde
        /*public int BeregnPuls(List<double> blodtryksListe)
        {
            return blodtryk.BeregnPuls(blodtryksListe);
        }*/

        //Unittest - 09-12-2015 - Brian
        public bool TjekSystoleOverskredet(List<double> blodtryksListe)
        {
            List<int> systoler = blodtryk.BeregnSystole(blodtryksListe);
            bool grænseværdioverskredet = false;

            foreach (int systole in systoler)
            {
                if (systole > systoleGrænseVærdi.ØvreGrænseVærdi || systole < systoleGrænseVærdi.NedreGrænseVærdi)
                {
                    grænseværdioverskredet = true;
                }

                else grænseværdioverskredet = false;
            }

            return grænseværdioverskredet;
        }

        //Unittest - 09-12-2015 - Brian
        public bool TjekDiastoleOverskredet(List<double> blodtryksListe)
        {
            List<int> diastoler = blodtryk.BeregnDiastole(blodtryksListe);

            bool grænseværdioverskredet = false;

            foreach(int diastole in diastoler)
            { 
                if (diastole > diastoleGrænseVærdi.ØvreGrænseVærdi || diastole < diastoleGrænseVærdi.NedreGrænseVærdi)
                {
                    grænseværdioverskredet = true;
                }
                else grænseværdioverskredet = false;
            }

            return grænseværdioverskredet;
        }

        //Unittest - 09-12-2015 - Brian
        public List<int> SystoleListe(List<double> blodtryksListe)
        {
            return blodtryk.BeregnSystole(blodtryksListe);
        }

        //Unittest - 09-12-2015 - Brian
        public List<int> DiastoleListe(List<double> blodtryksListe)
        {
            return blodtryk.BeregnDiastole(blodtryksListe);
        }

        //Unittest - 09-12-2015 - Brian
        public List<int> Middeltrykliste(List<int> systoleliste, List<int> diastoleliste, List<double> blodtryksListe)
        {
           return blodtryk.BeregnMiddeltryk(systoleliste, diastoleliste, blodtryksListe);
        }

        #region benyttes ikke - fremtidigt arbejde
        public void BeregnEKG(int puls)
        {

        }

        public void UdsaetAlarm()
        {

        }

        public void StopLyd()
        {

        }

        public void HentEKGdata()
        {
            //port,min,max,rate, sample ????
        }
        #endregion

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO SystoleOP()
        {
            int nedre = systoleGrænseVærdi.NedreGrænseVærdi;
            nedre++;
            int øvre = systoleGrænseVærdi.ØvreGrænseVærdi;
            øvre++;

            systoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return systoleGrænseVærdi;
        }

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO SystoleNED()
        {
            int nedre = systoleGrænseVærdi.NedreGrænseVærdi;
            nedre--;
            int øvre = systoleGrænseVærdi.ØvreGrænseVærdi;
            øvre--;

            systoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return systoleGrænseVærdi;
        }

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO DiastoleOP()
        {
            int nedre = diastoleGrænseVærdi.NedreGrænseVærdi;
            nedre++;
            int øvre = diastoleGrænseVærdi.ØvreGrænseVærdi;
            øvre++;

            diastoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return diastoleGrænseVærdi;
        }

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO DiastoleNED()
        {
            int nedre = diastoleGrænseVærdi.NedreGrænseVærdi;
            nedre--;
            int øvre = diastoleGrænseVærdi.ØvreGrænseVærdi;
            øvre--;

            diastoleGrænseVærdi = new GrænseVærdiDTO(nedre, øvre);
            return diastoleGrænseVærdi;
        }

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO HentSystoleGrænseværdier()
        {
            return systoleGrænseVærdi;
        }

        //Unittest - 09-12-2015 - Brian
        public GrænseVærdiDTO HentDiastoleGrænseværdier()
        {
            return diastoleGrænseVærdi;
        }

        public void setNulpunktsJustering(double nulpunktsværdi)
        {
            nulpunkt = nulpunktsværdi;
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify(double[] graftilGUIMålinger)
        {
            foreach (IObserver obs in observers)
            {
                obs.Update(graftilGUIMålinger);
            }
        }

        public void Update(double[] graf)
        {
            Blodtryksværdiliste.AddRange(graf);
            BTDataTilDB.AddRange(graf);

           // nulpunkt = BTDataTilDB.Average();

            if (BTDataTilDB.Count > 1000)
            {
                data.GemBTData(Patient.CPR, kalibreringstal, nulpunkt, BTDataTilDB.ToArray());
                BTDataTilDB.Clear();
            }
        }
    }
}