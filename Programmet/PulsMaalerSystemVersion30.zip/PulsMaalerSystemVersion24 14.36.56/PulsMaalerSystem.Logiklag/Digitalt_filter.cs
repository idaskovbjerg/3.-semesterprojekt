﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using PulsMaalerSystem.Datalag;


namespace PulsMaalerSystem.Logiklag
{
    public class Digitalt_filter 
    {
        DataLag data = new DataLag();
        bool filterOn;
        
        public Digitalt_filter()
        {
            filterOn = true;
        }

        //Unittest - 09-12-2015 - Brian
        public bool IsFilterOn()
        {
            return filterOn;
        }

        public void SetFilterOn()
        {
            filterOn = true;   
        }

        public void SetFilterOff()
        {
            filterOn = false;
        }

        //Unittest - 09-12-2015 - Brian
        public double[] FilterMovingAverage(int frameSize, double[] blodtrykliste)
        {
            double sum = 0;
            double[] gennemsnit = new double[blodtrykliste.Length - frameSize + 1];

            for (int i = 0; i <= blodtrykliste.Length - frameSize; i++)
            {
                int tæller = 0;
                int index = i;

                while(tæller < frameSize)
                {
                    sum = sum + blodtrykliste[index];
                    
                    tæller += 1;
                    index += 1;
                }

                gennemsnit[i] = sum / frameSize;

                sum = 0;
            }

            return gennemsnit;
        }
    #region udkommenteret kode
        //public List<double> Filter(List<double> grafdata)
        //{
           

        //    var bb = new List<double> {  0.0007, 0.0009, 0.0013, 0.0020, 0.0028, 0.0038, 0.0051, 0.0065, 0.0082,  0.0101, 0.0122, 0.0145, 0.0170, 0.0196, 0.0223, 0.0250, 0.0277, 0.0303, 0.0329, 0.0352, 0.0373, 0.0390, 0.0405, 0.0415, 0.0422, 0.0424, 0.0422, 0.0415, 0.0405, 0.0390, 0.0373, 0.0352, 0.0329, 0.0303,
        //        0.0277, 0.0250, 0.0223, 0.0196, 0.0170, 0.0145, 0.0122, 0.0101, 0.0082, 0.0065, 0.0051, 0.0038, 0.0028, 0.0020, 0.0013, 0.0009, 0.0007};
        //   // var xx = new List<double> (grafdata);

        //    List<double> yy = func_FIR(bb, grafdata);

        //    //for (int i = 0; i < yy.Count; i++)
        //    //{
        //    //    Console.WriteLine("y[{0}] = {1}", i, yy[i]);
        //    //}
        //    return yy;
        //}

        //public static List<double> func_FIR(List<double> b, List<double> x)
        //{
        //    //y[n]=b0x[n]+b1x[n-1]+....bmx[n-M]

        //    var y = new List<double>();

        //    int M = b.Count;
        //    int n = x.Count;

        //    double t = 0.0;

        //    for (int j = 0; j < n; j++)
        //    {
        //        for (int i = 0; i < M; i++)
        //        {
        //            t += b[i] * x[n - i - 1];
        //        }
        //        y.Add(t);
        //    }

        //    return y;
        //}

#endregion
    }
}
