﻿namespace PulsMaalerSystem
{
    partial class HovedGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HovedGUI));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.DigitaltfilterON = new System.Windows.Forms.Button();
            this.DigitaltfilterOFF = new System.Windows.Forms.Button();
            this.digitalFilter = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tandKnap = new System.Windows.Forms.Button();
            this.EKG = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Blodtryk = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pulsTextbox = new System.Windows.Forms.TextBox();
            this.blodtrykTextbox = new System.Windows.Forms.TextBox();
            this.systoleOP = new System.Windows.Forms.Button();
            this.diastoleNED = new System.Windows.Forms.Button();
            this.systoleNED = new System.Windows.Forms.Button();
            this.diastoleOP = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Iltmætning = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.systoleValues = new System.Windows.Forms.TextBox();
            this.diastoleValues = new System.Windows.Forms.TextBox();
            this.nulpunktKnap = new System.Windows.Forms.Button();
            this.slukKnap = new System.Windows.Forms.Button();
            this.tidTextBox = new System.Windows.Forms.TextBox();
            this.alarmKnap = new System.Windows.Forms.Button();
            this.afbrydKnap = new System.Windows.Forms.Button();
            this.ekgLabel = new System.Windows.Forms.Label();
            this.middelLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.diaOpLabel = new System.Windows.Forms.Label();
            this.diaNedLabel = new System.Windows.Forms.Label();
            this.sysNedLabel = new System.Windows.Forms.Label();
            this.sysOpLabel = new System.Windows.Forms.Label();
            this.navnLabel = new System.Windows.Forms.Label();
            this.CPRlabel = new System.Windows.Forms.Label();
            this.sysLabel = new System.Windows.Forms.Label();
            this.diaLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.npj_værdi_textBox = new System.Windows.Forms.TextBox();
            this.radioButtonON = new System.Windows.Forms.RadioButton();
            this.radioButtonOFF = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.EKG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Blodtryk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iltmætning)).BeginInit();
            this.SuspendLayout();
            // 
            // DigitaltfilterON
            // 
            this.DigitaltfilterON.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigitaltfilterON.Location = new System.Drawing.Point(227, 1378);
            this.DigitaltfilterON.Margin = new System.Windows.Forms.Padding(8);
            this.DigitaltfilterON.Name = "DigitaltfilterON";
            this.DigitaltfilterON.Size = new System.Drawing.Size(238, 107);
            this.DigitaltfilterON.TabIndex = 0;
            this.DigitaltfilterON.Text = "ON";
            this.DigitaltfilterON.UseVisualStyleBackColor = true;
            // 
            // DigitaltfilterOFF
            // 
            this.DigitaltfilterOFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigitaltfilterOFF.Location = new System.Drawing.Point(456, 1378);
            this.DigitaltfilterOFF.Margin = new System.Windows.Forms.Padding(8);
            this.DigitaltfilterOFF.Name = "DigitaltfilterOFF";
            this.DigitaltfilterOFF.Size = new System.Drawing.Size(238, 107);
            this.DigitaltfilterOFF.TabIndex = 1;
            this.DigitaltfilterOFF.Text = "OFF";
            this.DigitaltfilterOFF.UseVisualStyleBackColor = true;
            // 
            // digitalFilter
            // 
            this.digitalFilter.AutoSize = true;
            this.digitalFilter.Location = new System.Drawing.Point(218, 1338);
            this.digitalFilter.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.digitalFilter.Name = "digitalFilter";
            this.digitalFilter.Size = new System.Drawing.Size(93, 33);
            this.digitalFilter.TabIndex = 2;
            this.digitalFilter.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(369, 551);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Digitalt filter";
            // 
            // tandKnap
            // 
            this.tandKnap.BackColor = System.Drawing.SystemColors.Control;
            this.tandKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tandKnap.ForeColor = System.Drawing.Color.Black;
            this.tandKnap.Location = new System.Drawing.Point(18, 492);
            this.tandKnap.Name = "tandKnap";
            this.tandKnap.Size = new System.Drawing.Size(98, 64);
            this.tandKnap.TabIndex = 7;
            this.tandKnap.Text = "TÆND";
            this.tandKnap.UseVisualStyleBackColor = false;
            this.tandKnap.Click += new System.EventHandler(this.tandKnap_Click);
            // 
            // EKG
            // 
            this.EKG.BackColor = System.Drawing.Color.Black;
            this.EKG.BackImageTransparentColor = System.Drawing.Color.White;
            this.EKG.BackSecondaryColor = System.Drawing.Color.Black;
            chartArea7.AxisX.LineColor = System.Drawing.Color.DimGray;
            chartArea7.AxisX.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea7.AxisX.MinorGrid.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.AxisX2.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.AxisY.LineColor = System.Drawing.Color.DimGray;
            chartArea7.AxisY.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea7.AxisY.MinorGrid.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.AxisY2.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.AxisY2.MajorGrid.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.AxisY2.MajorTickMark.LineColor = System.Drawing.Color.DarkGray;
            chartArea7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            chartArea7.BorderColor = System.Drawing.Color.White;
            chartArea7.Name = "ChartArea1";
            this.EKG.ChartAreas.Add(chartArea7);
            this.EKG.Location = new System.Drawing.Point(-1, 31);
            this.EKG.Name = "EKG";
            this.EKG.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.EKG.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.Lime};
            series7.BackSecondaryColor = System.Drawing.Color.Black;
            series7.BorderColor = System.Drawing.Color.Black;
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series7.Color = System.Drawing.Color.Lime;
            series7.LabelBackColor = System.Drawing.Color.White;
            series7.Name = "EKG";
            this.EKG.Series.Add(series7);
            this.EKG.Size = new System.Drawing.Size(925, 147);
            this.EKG.TabIndex = 8;
            this.EKG.Text = "ekg";
            // 
            // Blodtryk
            // 
            this.Blodtryk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.Blodtryk.BackImageTransparentColor = System.Drawing.Color.White;
            chartArea8.AxisX.InterlacedColor = System.Drawing.Color.White;
            chartArea8.AxisX.LineColor = System.Drawing.Color.DimGray;
            chartArea8.AxisX.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea8.AxisY.LineColor = System.Drawing.Color.DimGray;
            chartArea8.AxisY.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            chartArea8.Name = "ChartArea1";
            this.Blodtryk.ChartAreas.Add(chartArea8);
            this.Blodtryk.Location = new System.Drawing.Point(-1, 161);
            this.Blodtryk.Name = "Blodtryk";
            this.Blodtryk.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            this.Blodtryk.PaletteCustomColors = new System.Drawing.Color[] {
        System.Drawing.Color.Red};
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series8.Name = "Arterietryk";
            this.Blodtryk.Series.Add(series8);
            this.Blodtryk.Size = new System.Drawing.Size(925, 195);
            this.Blodtryk.TabIndex = 9;
            this.Blodtryk.Text = "blodtryk";
            // 
            // pulsTextbox
            // 
            this.pulsTextbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.pulsTextbox.Enabled = false;
            this.pulsTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pulsTextbox.ForeColor = System.Drawing.Color.Lime;
            this.pulsTextbox.Location = new System.Drawing.Point(931, 13);
            this.pulsTextbox.Multiline = true;
            this.pulsTextbox.Name = "pulsTextbox";
            this.pulsTextbox.Size = new System.Drawing.Size(140, 147);
            this.pulsTextbox.TabIndex = 11;
            // 
            // blodtrykTextbox
            // 
            this.blodtrykTextbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.blodtrykTextbox.Enabled = false;
            this.blodtrykTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blodtrykTextbox.ForeColor = System.Drawing.Color.Red;
            this.blodtrykTextbox.Location = new System.Drawing.Point(931, 176);
            this.blodtrykTextbox.Multiline = true;
            this.blodtrykTextbox.Name = "blodtrykTextbox";
            this.blodtrykTextbox.Size = new System.Drawing.Size(140, 147);
            this.blodtrykTextbox.TabIndex = 12;
            // 
            // systoleOP
            // 
            this.systoleOP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("systoleOP.BackgroundImage")));
            this.systoleOP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.systoleOP.Location = new System.Drawing.Point(1116, 161);
            this.systoleOP.Name = "systoleOP";
            this.systoleOP.Size = new System.Drawing.Size(80, 66);
            this.systoleOP.TabIndex = 13;
            this.systoleOP.Text = " ";
            this.systoleOP.UseVisualStyleBackColor = true;
            this.systoleOP.Click += new System.EventHandler(this.systoleOP_Click);
            // 
            // diastoleNED
            // 
            this.diastoleNED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("diastoleNED.BackgroundImage")));
            this.diastoleNED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.diastoleNED.Location = new System.Drawing.Point(1116, 410);
            this.diastoleNED.Name = "diastoleNED";
            this.diastoleNED.Size = new System.Drawing.Size(80, 66);
            this.diastoleNED.TabIndex = 14;
            this.diastoleNED.Text = " ";
            this.diastoleNED.UseVisualStyleBackColor = true;
            this.diastoleNED.Click += new System.EventHandler(this.diastoleNED_Click);
            // 
            // systoleNED
            // 
            this.systoleNED.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("systoleNED.BackgroundImage")));
            this.systoleNED.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.systoleNED.Location = new System.Drawing.Point(1116, 224);
            this.systoleNED.Name = "systoleNED";
            this.systoleNED.Size = new System.Drawing.Size(80, 66);
            this.systoleNED.TabIndex = 16;
            this.systoleNED.Text = " ";
            this.systoleNED.UseVisualStyleBackColor = true;
            this.systoleNED.Click += new System.EventHandler(this.systoleNED_Click);
            // 
            // diastoleOP
            // 
            this.diastoleOP.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("diastoleOP.BackgroundImage")));
            this.diastoleOP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.diastoleOP.Location = new System.Drawing.Point(1116, 347);
            this.diastoleOP.Name = "diastoleOP";
            this.diastoleOP.Size = new System.Drawing.Size(80, 66);
            this.diastoleOP.TabIndex = 15;
            this.diastoleOP.Text = " ";
            this.diastoleOP.UseVisualStyleBackColor = true;
            this.diastoleOP.Click += new System.EventHandler(this.diastoleOP_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(1114, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 33);
            this.label2.TabIndex = 17;
            this.label2.Text = "Systole";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1114, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 33);
            this.label3.TabIndex = 18;
            this.label3.Text = "Diastole";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.textBox1.Location = new System.Drawing.Point(931, 339);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(140, 147);
            this.textBox1.TabIndex = 20;
            // 
            // Iltmætning
            // 
            this.Iltmætning.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.Iltmætning.BackImageTransparentColor = System.Drawing.Color.Transparent;
            this.Iltmætning.BackSecondaryColor = System.Drawing.Color.White;
            chartArea9.AxisX.LineColor = System.Drawing.Color.DimGray;
            chartArea9.AxisX.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea9.AxisX2.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea9.AxisY.LineColor = System.Drawing.Color.DimGray;
            chartArea9.AxisY.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea9.AxisY2.MajorGrid.LineColor = System.Drawing.Color.DimGray;
            chartArea9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            chartArea9.Name = "ChartArea1";
            this.Iltmætning.ChartAreas.Add(chartArea9);
            this.Iltmætning.Location = new System.Drawing.Point(-1, 338);
            this.Iltmætning.Name = "Iltmætning";
            this.Iltmætning.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series9.Name = "Iltmætning";
            this.Iltmætning.Series.Add(series9);
            this.Iltmætning.Size = new System.Drawing.Size(925, 148);
            this.Iltmætning.TabIndex = 19;
            this.Iltmætning.Text = "iltmætning";
            // 
            // systoleValues
            // 
            this.systoleValues.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.systoleValues.Enabled = false;
            this.systoleValues.Location = new System.Drawing.Point(1202, 161);
            this.systoleValues.Multiline = true;
            this.systoleValues.Name = "systoleValues";
            this.systoleValues.Size = new System.Drawing.Size(100, 129);
            this.systoleValues.TabIndex = 21;
            // 
            // diastoleValues
            // 
            this.diastoleValues.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.diastoleValues.Enabled = false;
            this.diastoleValues.Location = new System.Drawing.Point(1202, 347);
            this.diastoleValues.Multiline = true;
            this.diastoleValues.Name = "diastoleValues";
            this.diastoleValues.Size = new System.Drawing.Size(100, 129);
            this.diastoleValues.TabIndex = 22;
            // 
            // nulpunktKnap
            // 
            this.nulpunktKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nulpunktKnap.ForeColor = System.Drawing.Color.Black;
            this.nulpunktKnap.Location = new System.Drawing.Point(582, 556);
            this.nulpunktKnap.Name = "nulpunktKnap";
            this.nulpunktKnap.Size = new System.Drawing.Size(116, 70);
            this.nulpunktKnap.TabIndex = 24;
            this.nulpunktKnap.Text = "Nulpunkts justering";
            this.nulpunktKnap.UseVisualStyleBackColor = true;
            this.nulpunktKnap.Click += new System.EventHandler(this.nulpunktKnap_Click);
            // 
            // slukKnap
            // 
            this.slukKnap.BackColor = System.Drawing.SystemColors.Control;
            this.slukKnap.Enabled = false;
            this.slukKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slukKnap.ForeColor = System.Drawing.Color.Black;
            this.slukKnap.Location = new System.Drawing.Point(18, 562);
            this.slukKnap.Name = "slukKnap";
            this.slukKnap.Size = new System.Drawing.Size(98, 64);
            this.slukKnap.TabIndex = 25;
            this.slukKnap.Text = "SLUK";
            this.slukKnap.UseVisualStyleBackColor = false;
            this.slukKnap.Click += new System.EventHandler(this.slukKnap_Click);
            // 
            // tidTextBox
            // 
            this.tidTextBox.BackColor = System.Drawing.Color.RoyalBlue;
            this.tidTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tidTextBox.ForeColor = System.Drawing.Color.White;
            this.tidTextBox.Location = new System.Drawing.Point(138, 525);
            this.tidTextBox.Multiline = true;
            this.tidTextBox.Name = "tidTextBox";
            this.tidTextBox.Size = new System.Drawing.Size(119, 101);
            this.tidTextBox.TabIndex = 26;
            this.tidTextBox.Text = " 00:00:00";
            this.tidTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // alarmKnap
            // 
            this.alarmKnap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("alarmKnap.BackgroundImage")));
            this.alarmKnap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.alarmKnap.Location = new System.Drawing.Point(1172, 13);
            this.alarmKnap.Name = "alarmKnap";
            this.alarmKnap.Size = new System.Drawing.Size(100, 87);
            this.alarmKnap.TabIndex = 27;
            this.alarmKnap.Text = " ";
            this.alarmKnap.UseVisualStyleBackColor = true;
            this.alarmKnap.Click += new System.EventHandler(this.alarmKnap_Click);
            // 
            // afbrydKnap
            // 
            this.afbrydKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.afbrydKnap.ForeColor = System.Drawing.Color.Black;
            this.afbrydKnap.Location = new System.Drawing.Point(1229, 585);
            this.afbrydKnap.Name = "afbrydKnap";
            this.afbrydKnap.Size = new System.Drawing.Size(113, 57);
            this.afbrydKnap.TabIndex = 28;
            this.afbrydKnap.Text = "Log ud";
            this.afbrydKnap.UseVisualStyleBackColor = true;
            this.afbrydKnap.Click += new System.EventHandler(this.afbrydKnap_Click);
            // 
            // ekgLabel
            // 
            this.ekgLabel.AutoSize = true;
            this.ekgLabel.BackColor = System.Drawing.Color.Transparent;
            this.ekgLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ekgLabel.ForeColor = System.Drawing.Color.Lime;
            this.ekgLabel.Location = new System.Drawing.Point(936, 16);
            this.ekgLabel.Name = "ekgLabel";
            this.ekgLabel.Size = new System.Drawing.Size(56, 55);
            this.ekgLabel.TabIndex = 29;
            this.ekgLabel.Text = "--";
            // 
            // middelLabel
            // 
            this.middelLabel.AutoSize = true;
            this.middelLabel.BackColor = System.Drawing.Color.Transparent;
            this.middelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middelLabel.ForeColor = System.Drawing.Color.Red;
            this.middelLabel.Location = new System.Drawing.Point(986, 233);
            this.middelLabel.Name = "middelLabel";
            this.middelLabel.Size = new System.Drawing.Size(55, 33);
            this.middelLabel.TabIndex = 32;
            this.middelLabel.Text = "(--)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label8.Location = new System.Drawing.Point(933, 347);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 55);
            this.label8.TabIndex = 33;
            this.label8.Text = "---";
            // 
            // diaOpLabel
            // 
            this.diaOpLabel.AutoSize = true;
            this.diaOpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diaOpLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.diaOpLabel.Location = new System.Drawing.Point(1212, 360);
            this.diaOpLabel.Name = "diaOpLabel";
            this.diaOpLabel.Size = new System.Drawing.Size(60, 42);
            this.diaOpLabel.TabIndex = 34;
            this.diaOpLabel.Text = "90";
            // 
            // diaNedLabel
            // 
            this.diaNedLabel.AutoSize = true;
            this.diaNedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diaNedLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.diaNedLabel.Location = new System.Drawing.Point(1212, 421);
            this.diaNedLabel.Name = "diaNedLabel";
            this.diaNedLabel.Size = new System.Drawing.Size(60, 42);
            this.diaNedLabel.TabIndex = 35;
            this.diaNedLabel.Text = "60";
            // 
            // sysNedLabel
            // 
            this.sysNedLabel.AutoSize = true;
            this.sysNedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sysNedLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sysNedLabel.Location = new System.Drawing.Point(1211, 234);
            this.sysNedLabel.Name = "sysNedLabel";
            this.sysNedLabel.Size = new System.Drawing.Size(81, 42);
            this.sysNedLabel.TabIndex = 37;
            this.sysNedLabel.Text = "100";
            // 
            // sysOpLabel
            // 
            this.sysOpLabel.AutoSize = true;
            this.sysOpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sysOpLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sysOpLabel.Location = new System.Drawing.Point(1211, 173);
            this.sysOpLabel.Name = "sysOpLabel";
            this.sysOpLabel.Size = new System.Drawing.Size(81, 42);
            this.sysOpLabel.TabIndex = 36;
            this.sysOpLabel.Text = "140";
            // 
            // navnLabel
            // 
            this.navnLabel.AutoSize = true;
            this.navnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.navnLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.navnLabel.Location = new System.Drawing.Point(13, 13);
            this.navnLabel.Name = "navnLabel";
            this.navnLabel.Size = new System.Drawing.Size(45, 20);
            this.navnLabel.TabIndex = 38;
            this.navnLabel.Text = "Navn";
            // 
            // CPRlabel
            // 
            this.CPRlabel.AutoSize = true;
            this.CPRlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CPRlabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.CPRlabel.Location = new System.Drawing.Point(14, 31);
            this.CPRlabel.Name = "CPRlabel";
            this.CPRlabel.Size = new System.Drawing.Size(42, 20);
            this.CPRlabel.TabIndex = 39;
            this.CPRlabel.Text = "CPR";
            // 
            // sysLabel
            // 
            this.sysLabel.AutoSize = true;
            this.sysLabel.BackColor = System.Drawing.Color.Transparent;
            this.sysLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sysLabel.ForeColor = System.Drawing.Color.Red;
            this.sysLabel.Location = new System.Drawing.Point(936, 181);
            this.sysLabel.Name = "sysLabel";
            this.sysLabel.Size = new System.Drawing.Size(64, 51);
            this.sysLabel.TabIndex = 40;
            this.sysLabel.Text = "---";
            // 
            // diaLabel
            // 
            this.diaLabel.AutoSize = true;
            this.diaLabel.BackColor = System.Drawing.Color.Transparent;
            this.diaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 32.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.diaLabel.ForeColor = System.Drawing.Color.Red;
            this.diaLabel.Location = new System.Drawing.Point(936, 267);
            this.diaLabel.Name = "diaLabel";
            this.diaLabel.Size = new System.Drawing.Size(50, 51);
            this.diaLabel.TabIndex = 42;
            this.diaLabel.Text = "--";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(704, 556);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 24);
            this.label4.TabIndex = 43;
            this.label4.Text = "Indtast værdi";
            // 
            // npj_værdi_textBox
            // 
            this.npj_værdi_textBox.Location = new System.Drawing.Point(710, 586);
            this.npj_værdi_textBox.Name = "npj_værdi_textBox";
            this.npj_værdi_textBox.Size = new System.Drawing.Size(100, 40);
            this.npj_værdi_textBox.TabIndex = 44;
            // 
            // radioButtonON
            // 
            this.radioButtonON.AutoSize = true;
            this.radioButtonON.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonON.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonON.Location = new System.Drawing.Point(377, 584);
            this.radioButtonON.Name = "radioButtonON";
            this.radioButtonON.Size = new System.Drawing.Size(47, 42);
            this.radioButtonON.TabIndex = 45;
            this.radioButtonON.TabStop = true;
            this.radioButtonON.Text = "ON";
            this.radioButtonON.UseVisualStyleBackColor = true;
            this.radioButtonON.CheckedChanged += new System.EventHandler(this.radioButtonON_CheckedChanged);
            // 
            // radioButtonOFF
            // 
            this.radioButtonOFF.AutoSize = true;
            this.radioButtonOFF.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.radioButtonOFF.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonOFF.Location = new System.Drawing.Point(430, 584);
            this.radioButtonOFF.Name = "radioButtonOFF";
            this.radioButtonOFF.Size = new System.Drawing.Size(58, 42);
            this.radioButtonOFF.TabIndex = 46;
            this.radioButtonOFF.TabStop = true;
            this.radioButtonOFF.Text = "OFF";
            this.radioButtonOFF.UseVisualStyleBackColor = true;
            this.radioButtonOFF.Click += new System.EventHandler(this.radioButtonOFF_Click);
            // 
            // HovedGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(5)))), ((int)(((byte)(5)))));
            this.ClientSize = new System.Drawing.Size(1354, 654);
            this.Controls.Add(this.radioButtonOFF);
            this.Controls.Add(this.radioButtonON);
            this.Controls.Add(this.npj_værdi_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.diaLabel);
            this.Controls.Add(this.sysLabel);
            this.Controls.Add(this.CPRlabel);
            this.Controls.Add(this.navnLabel);
            this.Controls.Add(this.sysNedLabel);
            this.Controls.Add(this.sysOpLabel);
            this.Controls.Add(this.diaNedLabel);
            this.Controls.Add(this.diaOpLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ekgLabel);
            this.Controls.Add(this.middelLabel);
            this.Controls.Add(this.afbrydKnap);
            this.Controls.Add(this.alarmKnap);
            this.Controls.Add(this.tidTextBox);
            this.Controls.Add(this.slukKnap);
            this.Controls.Add(this.diastoleNED);
            this.Controls.Add(this.systoleOP);
            this.Controls.Add(this.nulpunktKnap);
            this.Controls.Add(this.diastoleOP);
            this.Controls.Add(this.diastoleValues);
            this.Controls.Add(this.systoleValues);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Iltmætning);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.systoleNED);
            this.Controls.Add(this.blodtrykTextbox);
            this.Controls.Add(this.pulsTextbox);
            this.Controls.Add(this.Blodtryk);
            this.Controls.Add(this.EKG);
            this.Controls.Add(this.tandKnap);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.digitalFilter);
            this.Controls.Add(this.DigitaltfilterOFF);
            this.Controls.Add(this.DigitaltfilterON);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "HovedGUI";
            this.Text = "Hovedskærm";
            this.Load += new System.EventHandler(this.HovedGUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.EKG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Blodtryk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Iltmætning)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DigitaltfilterON;
        private System.Windows.Forms.Button DigitaltfilterOFF;
        private System.Windows.Forms.Label digitalFilter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button tandKnap;
        private System.Windows.Forms.DataVisualization.Charting.Chart EKG;
        private System.Windows.Forms.DataVisualization.Charting.Chart Blodtryk;
        private System.Windows.Forms.TextBox pulsTextbox;
        private System.Windows.Forms.TextBox blodtrykTextbox;
        private System.Windows.Forms.Button systoleOP;
        private System.Windows.Forms.Button diastoleNED;
        private System.Windows.Forms.Button systoleNED;
        private System.Windows.Forms.Button diastoleOP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataVisualization.Charting.Chart Iltmætning;
        private System.Windows.Forms.TextBox systoleValues;
        private System.Windows.Forms.TextBox diastoleValues;
        private System.Windows.Forms.Button nulpunktKnap;
        private System.Windows.Forms.Button slukKnap;
        private System.Windows.Forms.TextBox tidTextBox;
        private System.Windows.Forms.Button alarmKnap;
        private System.Windows.Forms.Button afbrydKnap;
        private System.Windows.Forms.Label ekgLabel;
        private System.Windows.Forms.Label middelLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label diaOpLabel;
        private System.Windows.Forms.Label diaNedLabel;
        private System.Windows.Forms.Label sysNedLabel;
        private System.Windows.Forms.Label sysOpLabel;
        private System.Windows.Forms.Label navnLabel;
        private System.Windows.Forms.Label CPRlabel;
        private System.Windows.Forms.Label sysLabel;
        private System.Windows.Forms.Label diaLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox npj_værdi_textBox;
        private System.Windows.Forms.RadioButton radioButtonON;
        private System.Windows.Forms.RadioButton radioButtonOFF;
    }
}

