﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.Logiklag
{
    class Alarm
    {
       

        public Alarm()
        {
         
        }


        private void StartAlarm()
        {
   
        }


        private void UdsaetAlarm()
        {

        }

        private void StopLyd()
        {

        }
    }
}
