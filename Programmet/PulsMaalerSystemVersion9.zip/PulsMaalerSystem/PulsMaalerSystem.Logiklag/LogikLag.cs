﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
//using System.Data;
using PulsMaalerSystem;


namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag
    {
        DataLag data = new DataLag();
        


        public LogikLag()
        {
           
        }

        

        public List<double> hentBTdata(string port, double min, double max, double rate, int sample)
        {

            return data.hentBTdata(port, min, max, rate, sample);
        }

        //public List<double> hentEKGdata()
        //{
        //    return data.hentEKGdata();
        //}
        public bool getKode(string brugernavn, int kode)
        {
            return (kode.Equals(data.getKode(brugernavn)));

        }
        public string getCPR(string cpr, string valgtNavn)
        {
            return cpr; 
        }
        public bool isRunning()
        {
            return data.isRunning();
        }
        public void StopHentData()
        {
            data.StopHentData();
        }
        public List<double> blodtrykVaerdi()
        {
            return data.blodtrykVaerdi();
        }
        public List<string> listePatient(string brugernavn)
        {
            return data.PatientOpslag(brugernavn);
        }


        public void TjekSystole()
        {

        }
        
        public void TjekDiastole()
        {

        }

        public void VaerdiOverskrevet()
        {

        }

        public void Alarm()
        {

        }

        public void BeregnBlodtryk(int systole, int diastole, int middeltryk)
        {

        }

        public void BeregnEKG(int puls)
        {

        }

        public void UdsaetAlarm()
        {

        }

        public void StopLyd()
        {

        }

        public void HentEKGdata()
        {
            //port,min,max,rate, sample ????
        }

        public void DigiFilterOn()
        {

        }

        public void DigiFilterOn()
        {

        }
        public void SystoleOP()
        {

        }
        public void SystoleNED()
        {

        }
        public void DiastoleOP()
        {

        }
        public void DiastoleNED()
        {

        }
        public void NulpunktsJustering()
        {
            
        }
    }

}
