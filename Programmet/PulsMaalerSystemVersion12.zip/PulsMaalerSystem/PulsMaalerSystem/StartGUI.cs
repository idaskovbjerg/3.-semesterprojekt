﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;



namespace PulsMaalerSystem
{
    public partial class StartGUI : Form
    {
        private LogikLag logik;
        private HovedGUI hovedskærm;

        public StartGUI()
        {
            InitializeComponent();
            logik = new LogikLag();
            //passwordTextBox.PasswordChar = '*';
            
        }

        private void tjekBruger(string brugernavn, int kode)
        {
            patientComboBox.Enabled = false;
            if (logik.getKode(brugernavn, kode))
            {
                hovedskærm = new HovedGUI(brugernavn);
                patientComboBox.Enabled = true;
                label6.Text = "Logget på";
            }

            else
            {
                label6.Text = "Brugernavn og/eller kode indtastet forkert";
                patientComboBox.Enabled = false;
            }

        }
        


        private void opsætningKnap_SelectedIndexChanged(object sender, EventArgs e)
        {
            idTextBox.Enabled = true;
            passwordTextBox.Enabled = true;
            loginKnap.Enabled = true;
        }

        public void tjekPatient(string brugernavn)
        {
            foreach (var patienter in logik.listePatient(idTextBox.Text))
            {
                patientComboBox.Items.Add(patienter);
            }
        }
        private void loginKnap_Click(object sender, EventArgs e)
        {
            tjekBruger(idTextBox.Text, Convert.ToInt32(passwordTextBox.Text));
            patientComboBox.Items.Clear();
            tjekPatient(idTextBox.Text);
        }

        //public string valgtPatient()
        //{
            
        //    return logik.getCPR(,patientComboBox.SelectedItem.ToString());
        //}
        
        private void patientComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            hovedskærm.port = opsætningKnap.SelectedItem.ToString();
            hovedskærm.Show();
            this.Hide();
        }

                
              
        

        private void kalibreringKnap_Click(object sender, EventArgs e)
        {
            double værdi1;
            double værdi2;
            double værdi3;
            if( radioButton136.Checked)
            {
                værdi1 = 10 / Convert.ToDouble(VolttextBox.Text);
                værdi1label.Text = Convert.ToString(værdi1);
            }
            if (radioButton680.Checked)
            {
                værdi2 = 50 / Convert.ToDouble(VolttextBox.Text);
                værdi2label.Text = Convert.ToString(værdi2);
                
            }
            if(radioButton1360.Checked)
            {
                værdi3 = 100 / Convert.ToDouble(VolttextBox.Text);
                værdi3label.Text = Convert.ToString(værdi3);
            }
            
            
        }

        private void kalibreringsKnap_Enabled(object sender, EventArgs e)
        {
            kalibreringKnap.Enabled = true;
        }

        private void radioButton136_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(10);
        }

        private void radioButton680_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(50);
        }

        private void radioButton1360_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(100);
        }

       

        


        
    }
}
