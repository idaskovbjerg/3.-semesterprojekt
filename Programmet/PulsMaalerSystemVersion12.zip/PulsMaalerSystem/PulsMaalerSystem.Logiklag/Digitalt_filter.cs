﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace PulsMaalerSystem.Logiklag
{
    class Digitalt_filter 
    {
       
        public void DigiFilterOn()
        {

        }

        public void DigiFilterOff()
        {

        }
    }
}
