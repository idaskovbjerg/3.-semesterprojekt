﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;

namespace PulsMaalerSystem.Logiklag
{
    class Blodtryk
    {
        LogikLag logik;
        //private int systole;
        //private int diastole;
        //private int middeltryk;
        private List<double> blodtryksliste;
        private const int grænseværdiSys = 100;
        private const int grænseværdiDia = 90;
        private List<int> systoleliste;
        private List<int> diastoleliste;
        private List<int> middeltrykliste;
        public Blodtryk()
        {
            logik = new LogikLag();
            //sys = systole;
            //dia = diastole;
            //middel = middeltryk;
            blodtryksliste = logik.blodtrykVaerdi();

            
        }

        public List<int> BeregnSystole(List<int> systoleliste_)
        {
            systoleliste = new List<int>();
            for(int i=0; i < blodtryksliste.Count; i++)
            {
                if(blodtryksliste[i] > grænseværdiSys && blodtryksliste[i] > blodtryksliste[i+1])
                {
                    systoleliste.Add(i);
                    i += 50;
                }
                systoleliste_ = systoleliste;
            }

            return systoleliste_;
          
        }

        public List<int> BeregnDiastole(List<int> diastoleliste_)
        {
            diastoleliste = new List<int>();
            for (int i = 0; i < blodtryksliste.Count; i++)
            {
                if (blodtryksliste[i] < grænseværdiDia && blodtryksliste[i] < blodtryksliste[i + 1])
                {
                    diastoleliste.Add(i);
                    i += 50;
                }
                diastoleliste_ = diastoleliste;
            }

            return diastoleliste_;  
        }

        public List<int> BeregnMiddeltryk(List<int> middeltrykliste)
        {
            int middeltryk;
            middeltrykliste = new List<int>();
           for(int i = 0; i< blodtryksliste.Count; i++)
           {
               middeltryk = 2 / 3 * diastoleliste[i] + 1 / 3 * systoleliste[i];
               middeltrykliste.Add(middeltryk);

           }
           return middeltrykliste;
        }
    }
}
