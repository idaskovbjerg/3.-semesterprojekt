﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.Logiklag
{
    class EKG
    {
        private int puls_;

        public EKG(int puls)
        {
            puls = puls_;
        }


        private void BeregnPuls()
        {

        }

    }
}
