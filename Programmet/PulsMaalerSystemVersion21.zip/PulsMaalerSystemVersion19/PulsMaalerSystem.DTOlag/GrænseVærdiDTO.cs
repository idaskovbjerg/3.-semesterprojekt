﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.DTOlag
{
    public class GrænseVærdiDTO
    {
        public int NedreGrænseVærdi { get; set; }
        public int ØvreGrænseVærdi { get; set; }

        public GrænseVærdiDTO()
        {

        }

        public GrænseVærdiDTO(int nedre, int øvre)
        {
            NedreGrænseVærdi = nedre;
            ØvreGrænseVærdi = øvre;
        }
    }
}