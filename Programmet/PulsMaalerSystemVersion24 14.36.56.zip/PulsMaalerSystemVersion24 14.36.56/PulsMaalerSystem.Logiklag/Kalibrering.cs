﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.DTOlag;

namespace PulsMaalerSystem.Logiklag
{
    public class Kalibrering
    {
        public Kalibrering()
        {

        }

        public double BeregnKalibreringsTal(KalibreringDTO kalibreringstal)
        {
            double kalTal;

            kalTal = + kalibreringstal.Pressure_mmhg_ / kalibreringstal.Volt_; 

            return kalTal;
        }
    }
}
