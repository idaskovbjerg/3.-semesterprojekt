﻿create table Personale
(
Brugernavn nvarchar(4) PRIMARY KEY NOT NULL,
Adgangskode int not null
)