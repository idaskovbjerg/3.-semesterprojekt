﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using PulsMaalerSystem.Logiklag;

namespace PulsMaalerSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());



            LogikLag logik = new LogikLag();

            List<double> Blodtrykliste = logik.hentdata();
            List<double> EKGliste = logik.hentEKGdata();

            foreach (double d in Blodtrykliste)
            {
                Console.WriteLine(d);
            }
            foreach (double d2 in EKGliste)
            {
                Console.WriteLine(d2);
            }

            Console.ReadLine();
        }

            //Thread hentdatatråd = new Thread(HentvisBlodtryk);
            //Thread hentEKGdata = new Thread(HentvisEKG);

        //    hentdatatråd.Start();
        //    hentEKGdata.Start();
        //}

        //    public void HentvisBlodtryk()
        //    {
        //        List<double> Blodtrykliste = logik.hentdata();
                

        //    }
                       
        }
}
