﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;

namespace PulsMaalerSystem
{
    public partial class Form1 : Form
    {
        LogikLag logik;
        public Form1()
        {
            InitializeComponent();
            logik = new LogikLag();

            List<double> Blodtrykliste = logik.hentdata();
            List<double> EKGliste = logik.hentEKGdata();



        }

        private void tandKnap_Click(object sender, EventArgs e)
        {
            EKG.Series["EKG-signal"].Points.DataBindY(logik.hentEKGdata());
            Blodtryk.Series["Blodtryk-signal"].Points.DataBindY(logik.hentdata());


        }
    }


}
