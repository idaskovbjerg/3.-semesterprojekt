﻿namespace PulsMaalerSystem
{
    partial class StartGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kalibreringKnap = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.opsætningKnap = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.patientComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.loginKnap = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.VolttextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.radioButton136 = new System.Windows.Forms.RadioButton();
            this.radioButton680 = new System.Windows.Forms.RadioButton();
            this.radioButton1360 = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.mmHglabel = new System.Windows.Forms.Label();
            this.værdi1label = new System.Windows.Forms.Label();
            this.værdi2label = new System.Windows.Forms.Label();
            this.værdi3label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // kalibreringKnap
            // 
            this.kalibreringKnap.BackColor = System.Drawing.SystemColors.Control;
            this.kalibreringKnap.Enabled = false;
            this.kalibreringKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kalibreringKnap.Location = new System.Drawing.Point(502, 12);
            this.kalibreringKnap.Name = "kalibreringKnap";
            this.kalibreringKnap.Size = new System.Drawing.Size(139, 95);
            this.kalibreringKnap.TabIndex = 3;
            this.kalibreringKnap.Text = "Kalibrering";
            this.kalibreringKnap.UseVisualStyleBackColor = false;
            this.kalibreringKnap.Click += new System.EventHandler(this.kalibreringKnap_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Personale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Brugernavn";
            // 
            // idTextBox
            // 
            this.idTextBox.Enabled = false;
            this.idTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idTextBox.Location = new System.Drawing.Point(192, 168);
            this.idTextBox.Multiline = true;
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(120, 29);
            this.idTextBox.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 31);
            this.label3.TabIndex = 7;
            this.label3.Text = "Patient";
            // 
            // opsætningKnap
            // 
            this.opsætningKnap.FormattingEnabled = true;
            this.opsætningKnap.Items.AddRange(new object[] {
            "Dev1/ai0",
            "Dev2/ai0",
            "Dev3/ai0"});
            this.opsætningKnap.Location = new System.Drawing.Point(18, 48);
            this.opsætningKnap.Name = "opsætningKnap";
            this.opsætningKnap.Size = new System.Drawing.Size(141, 21);
            this.opsætningKnap.TabIndex = 1;
            this.opsætningKnap.SelectedIndexChanged += new System.EventHandler(this.opsætningKnap_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 31);
            this.label5.TabIndex = 12;
            this.label5.Text = "Opsætning";
            // 
            // patientComboBox
            // 
            this.patientComboBox.Enabled = false;
            this.patientComboBox.FormattingEnabled = true;
            this.patientComboBox.Location = new System.Drawing.Point(18, 348);
            this.patientComboBox.Name = "patientComboBox";
            this.patientComboBox.Size = new System.Drawing.Size(141, 21);
            this.patientComboBox.TabIndex = 5;
            this.patientComboBox.SelectedIndexChanged += new System.EventHandler(this.patientComboBox_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Adgangskode";
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Enabled = false;
            this.passwordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTextBox.Location = new System.Drawing.Point(192, 203);
            this.passwordTextBox.MaxLength = 4;
            this.passwordTextBox.Multiline = true;
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.PasswordChar = '*';
            this.passwordTextBox.Size = new System.Drawing.Size(120, 29);
            this.passwordTextBox.TabIndex = 3;
            // 
            // loginKnap
            // 
            this.loginKnap.Enabled = false;
            this.loginKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginKnap.Location = new System.Drawing.Point(220, 238);
            this.loginKnap.Name = "loginKnap";
            this.loginKnap.Size = new System.Drawing.Size(92, 33);
            this.loginKnap.TabIndex = 4;
            this.loginKnap.Text = "Log ind";
            this.loginKnap.UseVisualStyleBackColor = true;
            this.loginKnap.Click += new System.EventHandler(this.loginKnap_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Besked:";
            // 
            // VolttextBox
            // 
            this.VolttextBox.Location = new System.Drawing.Point(502, 184);
            this.VolttextBox.Name = "VolttextBox";
            this.VolttextBox.Size = new System.Drawing.Size(66, 20);
            this.VolttextBox.TabIndex = 19;
            this.VolttextBox.TextChanged += new System.EventHandler(this.kalibreringsKnap_Enabled);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(587, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "mmHg";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(587, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "Volt";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(587, 234);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Værdi1";
            // 
            // radioButton136
            // 
            this.radioButton136.AutoSize = true;
            this.radioButton136.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton136.Location = new System.Drawing.Point(503, 113);
            this.radioButton136.Name = "radioButton136";
            this.radioButton136.Size = new System.Drawing.Size(72, 20);
            this.radioButton136.TabIndex = 24;
            this.radioButton136.TabStop = true;
            this.radioButton136.Text = "136 mm";
            this.radioButton136.UseVisualStyleBackColor = true;
            this.radioButton136.CheckedChanged += new System.EventHandler(this.radioButton136_CheckedChanged);
            // 
            // radioButton680
            // 
            this.radioButton680.AutoSize = true;
            this.radioButton680.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton680.Location = new System.Drawing.Point(502, 137);
            this.radioButton680.Name = "radioButton680";
            this.radioButton680.Size = new System.Drawing.Size(72, 20);
            this.radioButton680.TabIndex = 25;
            this.radioButton680.TabStop = true;
            this.radioButton680.Text = "680 mm";
            this.radioButton680.UseVisualStyleBackColor = true;
            this.radioButton680.CheckedChanged += new System.EventHandler(this.radioButton680_CheckedChanged);
            // 
            // radioButton1360
            // 
            this.radioButton1360.AutoSize = true;
            this.radioButton1360.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1360.Location = new System.Drawing.Point(502, 161);
            this.radioButton1360.Name = "radioButton1360";
            this.radioButton1360.Size = new System.Drawing.Size(79, 20);
            this.radioButton1360.TabIndex = 26;
            this.radioButton1360.TabStop = true;
            this.radioButton1360.Text = "1360 mm";
            this.radioButton1360.UseVisualStyleBackColor = true;
            this.radioButton1360.CheckedChanged += new System.EventHandler(this.radioButton1360_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(587, 260);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 20);
            this.label10.TabIndex = 28;
            this.label10.Text = "Værdi2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(587, 286);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 20);
            this.label11.TabIndex = 30;
            this.label11.Text = "Værdi3";
            // 
            // mmHglabel
            // 
            this.mmHglabel.AutoSize = true;
            this.mmHglabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mmHglabel.Location = new System.Drawing.Point(499, 212);
            this.mmHglabel.Name = "mmHglabel";
            this.mmHglabel.Size = new System.Drawing.Size(13, 20);
            this.mmHglabel.TabIndex = 31;
            this.mmHglabel.Text = " ";
            // 
            // værdi1label
            // 
            this.værdi1label.AutoSize = true;
            this.værdi1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.værdi1label.Location = new System.Drawing.Point(499, 234);
            this.værdi1label.Name = "værdi1label";
            this.værdi1label.Size = new System.Drawing.Size(13, 20);
            this.værdi1label.TabIndex = 32;
            this.værdi1label.Text = " ";
            // 
            // værdi2label
            // 
            this.værdi2label.AutoSize = true;
            this.værdi2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.værdi2label.Location = new System.Drawing.Point(499, 260);
            this.værdi2label.Name = "værdi2label";
            this.værdi2label.Size = new System.Drawing.Size(13, 20);
            this.værdi2label.TabIndex = 33;
            this.værdi2label.Text = " ";
            // 
            // værdi3label
            // 
            this.værdi3label.AutoSize = true;
            this.værdi3label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.værdi3label.Location = new System.Drawing.Point(499, 286);
            this.værdi3label.Name = "værdi3label";
            this.værdi3label.Size = new System.Drawing.Size(13, 20);
            this.værdi3label.TabIndex = 34;
            this.værdi3label.Text = " ";
            // 
            // StartGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(653, 403);
            this.Controls.Add(this.værdi3label);
            this.Controls.Add(this.værdi2label);
            this.Controls.Add(this.værdi1label);
            this.Controls.Add(this.mmHglabel);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.radioButton1360);
            this.Controls.Add(this.radioButton680);
            this.Controls.Add(this.radioButton136);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.VolttextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.loginKnap);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.patientComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.opsætningKnap);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kalibreringKnap);
            this.Name = "StartGUI";
            this.Text = "Startskærm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button kalibreringKnap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox opsætningKnap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox patientComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Button loginKnap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox VolttextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton136;
        private System.Windows.Forms.RadioButton radioButton680;
        private System.Windows.Forms.RadioButton radioButton1360;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label mmHglabel;
        private System.Windows.Forms.Label værdi1label;
        private System.Windows.Forms.Label værdi2label;
        private System.Windows.Forms.Label værdi3label;
    }
}