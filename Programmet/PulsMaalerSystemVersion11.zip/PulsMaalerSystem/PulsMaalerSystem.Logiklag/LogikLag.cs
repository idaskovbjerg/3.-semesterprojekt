﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;
//using System.Data;
using PulsMaalerSystem;
using PulsMaalerSystem.DTOlag;
using System.Threading;
using System.Collections;



namespace PulsMaalerSystem.Logiklag
{
    public class LogikLag : ISubject
    {
        DataLag data;
        private List<IObserver> observers = null;
        private List<double> BTmålinger;
        private List<double> graftilGUIMålinger;
        private List<double> Blodtryksværdiliste;
        
        
        Thread tlogik;


        public LogikLag()
        {
            data = new DataLag();
            observers = new List<IObserver>();
            BTmålinger = new List<double>();
            graftilGUIMålinger = new List<double>();
            Blodtryksværdiliste = blodtrykVaerdi();

            for (int i = 0; i < 1000; i++)
            {
                graftilGUIMålinger.Add(0.0);
            }

            Notify(graftilGUIMålinger);

            tlogik = new Thread(StartHentData);

        }

        

        public void hentBTdata(string port, double min, double max, double rate, int sample) // henter det grimme
        {
            data.hentBTdata(port, min, max, rate, sample);
            tlogik.Start();
            
        }

       

        private void StartHentData()
        {
            while (isRunning())
            {
                //Hiv rådata ud så vi kan arbejde med dem
                blodtrykVaerdi();
                
                //Her skal vi behandle data
                //Her er en metode til digitalt filter - kan udelades lidt endnu

                //Nogle løkker og en masse fint til at holde styr på hvor langt vi er i rådata
                //De rådata skal kopieres over i List<double> (enqueue / dequeue)
                //Den liste skal sendes med i notify
                

                Notify();
            }
        }

        public void NyQueue()
        {
            Queue<double> myQ = new Queue<double>();
            myQ.Clear();

            for (int i = 0; i < graftilGUIMålinger.Count; i++)
            {
                myQ.Enqueue(graftilGUIMålinger[i]);
                myQ.Dequeue();
            }

            double[] BTarray = myQ.ToArray();
            var Køliste = new List<double>(BTarray);
        }

        



        //public List<double> hentEKGdata()
        //{
        //    return data.hentEKGdata();
        //}
        public bool getKode(string brugernavn, int kode)
        {
            return (kode.Equals(data.getKode(brugernavn)));

        }
        public string getCPR(string cpr, string valgtNavn)
        {
            return cpr; 
        }
        public bool isRunning()
        {
            return data.isRunning();
        }
        public void StopHentData()
        {
            data.StopHentData();
            tlogik.Abort();
        }
        public List<double> blodtrykVaerdi()
        {
            return data.blodtrykVaerdi();
        }
        public List<string> listePatient(string brugernavn)
        {
            return data.PatientOpslag(brugernavn);
        }


        public void TjekSystole()
        {
           
        }
        
        public void TjekDiastole()
        {

        }

        public void VaerdiOverskrevet()
        {

        }

        public void Alarm()
        {

        }

        public void BeregnBlodtryk(int systole, int diastole, int middeltryk)
        {

        }

        public void BeregnEKG(int puls)
        {

        }

        public void UdsaetAlarm()
        {

        }

        public void StopLyd()
        {

        }

        public void HentEKGdata()
        {
            //port,min,max,rate, sample ????
        }

        public void DigiFilterOn()
        {

        }

        public void DigiFilterOff()
        {

        }
        public void SystoleOP()
        {

        }
        public void SystoleNED()
        {

        }
        public void DiastoleOP()
        {

        }
        public void DiastoleNED()
        {

        }
        public void NulpunktsJustering()
        {
            
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);

        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify(List<double> graftilGUIMålinger)
        {
            foreach(IObserver obs in observers)
            {
                obs.Update(graftilGUIMålinger);
            }
        }
    }

}
