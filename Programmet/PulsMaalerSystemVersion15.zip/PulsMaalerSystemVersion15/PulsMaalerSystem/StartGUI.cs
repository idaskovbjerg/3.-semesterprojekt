﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using PulsMaalerSystem.DTOlag;



namespace PulsMaalerSystem
{
    public partial class StartGUI : Form
    {
        private LogikLag logik;
        private HovedGUI hovedskærm;
        private Kalibrering KaliKlasse;
        public StartGUI()
        {
            InitializeComponent();
            logik = new LogikLag();
            //passwordTextBox.PasswordChar = '*';
            KaliKlasse = new Kalibrering();
            
        }

        private void tjekBruger(string brugernavn, int kode)
        {
            patientComboBox.Enabled = false;
            if (logik.getKode(brugernavn, kode))
            {
                hovedskærm = new HovedGUI(brugernavn);
                patientComboBox.Enabled = true;
                label6.Text = "Logget på";
            }

            else
            {
                label6.Text = "Brugernavn og/eller kode indtastet forkert";
                patientComboBox.Enabled = false;
            }

        }
        


        private void opsætningKnap_SelectedIndexChanged(object sender, EventArgs e)
        {
            idTextBox.Enabled = true;
            passwordTextBox.Enabled = true;
            loginKnap.Enabled = true;
        }

        public void tjekPatient(string brugernavn)
        {
            foreach (var patienter in logik.listePatient(idTextBox.Text))
            {
                patientComboBox.Items.Add(patienter);
            }
        }
        private void loginKnap_Click(object sender, EventArgs e)
        {
            tjekBruger(idTextBox.Text, Convert.ToInt32(passwordTextBox.Text));
            patientComboBox.Items.Clear();
            tjekPatient(idTextBox.Text);
        }

        //public string valgtPatient()
        //{
            
        //    return logik.getCPR(,patientComboBox.SelectedItem.ToString());
        //}
        
        private void patientComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            hovedskærm.port = opsætningKnap.SelectedItem.ToString();
            hovedskærm.Show();
            this.Hide();
        }

                
              
        

        private void kalibreringKnap_Click(object sender, EventArgs e)
        {
            double værdi1;
            double værdi2;
            double værdi3;
            int tryk1 = 10;
            int tryk2 = 50;
            int tryk3 = 100;
            if( radioButton136.Checked)
            {
                KalibreringDTO kali1 = new KalibreringDTO(Convert.ToDouble(VolttextBox.Text),tryk1);
                værdi1 = KaliKlasse.BeregnKalibreringsTal(kali1);
                værdi1label.Text = Convert.ToString(værdi1);
            }
            if (radioButton680.Checked)
            {
                KalibreringDTO kali2 = new KalibreringDTO(Convert.ToDouble(VolttextBox.Text), tryk2);
                værdi2 = KaliKlasse.BeregnKalibreringsTal(kali2);
                
                værdi2label.Text = Convert.ToString(værdi2);
                
            }
            if(radioButton1360.Checked)
            {
                KalibreringDTO kali3 = new KalibreringDTO(Convert.ToDouble(VolttextBox.Text), tryk3);
                værdi3 = KaliKlasse.BeregnKalibreringsTal(kali3);
                værdi3label.Text = Convert.ToString(værdi3);
            }
            
            
        }

        private void kalibreringsKnap_Enabled(object sender, EventArgs e)
        {
            kalibreringKnap.Enabled = true;
        }

        private void radioButton136_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(10);
        }

        private void radioButton680_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(50);
        }

        private void radioButton1360_CheckedChanged(object sender, EventArgs e)
        {
            mmHglabel.Text = Convert.ToString(100);
        }

       

        


        
    }
}
