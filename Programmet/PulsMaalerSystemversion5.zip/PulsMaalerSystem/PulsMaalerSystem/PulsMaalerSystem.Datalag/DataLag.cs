﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ST2Prj2LibNI_DAQ;
using System.Data.SqlClient;

namespace PulsMaalerSystem.Datalag
{
    public class DataLag
    {
        NI_DAQVoltage DAQ = new NI_DAQVoltage();


        private SqlConnection conn;
        private SqlDataReader rdr;
        private SqlCommand cmd;
        private const String db = "F15ST2ITS2201404669"; // Tilrettes DB

        public DataLag()
        {
            // Opsætning af DB forbindelsen til SQL Server webhotel10.iha.dk og valgt database (db)
            conn = new SqlConnection("Data Source=webhotel10.iha.dk;Initial Catalog=" + db + ";Persist Security Info=True;User ID=" + db + ";Password=" + db + "");
        }

        
        public List<double> hentBTdata()
        {
            DAQ.deviceName = "Dev1/AI0";
            DAQ.sampleRateInHz = 50;
            DAQ.samplesPerChannel = 100;
            DAQ.getVoltageSeqBlocking();
            return DAQ.currentVoltageSeq;
        }
        public List<double> hentEKGdata()
        {
            DAQ.deviceName = "Dev1/AI2";
            DAQ.sampleRateInHz = 50;
            DAQ.samplesPerChannel = 100;
            DAQ.getVoltageSeqBlocking();
            return DAQ.currentVoltageSeq;
        }

        public int  BrugernavnOpslag(string brugernavn)
        {
            int result = 0;

            // Oprette
            cmd = new SqlCommand("select * from Personale where Brugernavn ='" + brugernavn + "'", conn);

            conn.Open();

            // Udføre 
            rdr = cmd.ExecuteReader();

            // Undersøge
            if (rdr.Read())
            {
                if (Convert.ToBoolean(rdr["Brugernavn"]))  // her udvælges kolonnen i resultattabellen med rdr[1], som converteres fra SQL-typen bit til C# typen boolean
                    result = 1; // Brugernavn er OK og registreret
                else
                    result = 2; // Brugernavn er ikke OK
            }

            // Lukke
            conn.Close();
            return result;
        }

        public int getKode(string brugernavn)
        {
            int resultat = 0;
            cmd = new SqlCommand("select Adgangskode from Personale where Brugernavn ='" + brugernavn + "'", conn);
            conn.Open();
            rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                resultat = rdr.GetInt32(0);
            }

            conn.Close();
            return resultat;
        }
    }
}
