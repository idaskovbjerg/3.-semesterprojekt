﻿namespace PulsMaalerSystem
{
    partial class StartGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kalibreringKnap = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.opsætningKnap = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.patientComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.loginKnap = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.mmHgtextBox = new System.Windows.Forms.TextBox();
            this.VolttextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.VærditextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // kalibreringKnap
            // 
            this.kalibreringKnap.BackColor = System.Drawing.SystemColors.Control;
            this.kalibreringKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kalibreringKnap.Location = new System.Drawing.Point(502, 12);
            this.kalibreringKnap.Name = "kalibreringKnap";
            this.kalibreringKnap.Size = new System.Drawing.Size(139, 95);
            this.kalibreringKnap.TabIndex = 3;
            this.kalibreringKnap.Text = "Kalibrering";
            this.kalibreringKnap.UseVisualStyleBackColor = false;
            this.kalibreringKnap.Click += new System.EventHandler(this.kalibreringKnap_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "Personale";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Brugernavn";
            // 
            // idTextBox
            // 
            this.idTextBox.Enabled = false;
            this.idTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idTextBox.Location = new System.Drawing.Point(192, 168);
            this.idTextBox.Multiline = true;
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(120, 29);
            this.idTextBox.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 31);
            this.label3.TabIndex = 7;
            this.label3.Text = "Patient";
            // 
            // opsætningKnap
            // 
            this.opsætningKnap.FormattingEnabled = true;
            this.opsætningKnap.Items.AddRange(new object[] {
            "Dev1/ai0",
            "Dev2/ai0",
            "Dev3/ai0"});
            this.opsætningKnap.Location = new System.Drawing.Point(18, 48);
            this.opsætningKnap.Name = "opsætningKnap";
            this.opsætningKnap.Size = new System.Drawing.Size(141, 21);
            this.opsætningKnap.TabIndex = 1;
            this.opsætningKnap.SelectedIndexChanged += new System.EventHandler(this.opsætningKnap_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 31);
            this.label5.TabIndex = 12;
            this.label5.Text = "Opsætning";
            // 
            // patientComboBox
            // 
            this.patientComboBox.Enabled = false;
            this.patientComboBox.FormattingEnabled = true;
            this.patientComboBox.Location = new System.Drawing.Point(18, 348);
            this.patientComboBox.Name = "patientComboBox";
            this.patientComboBox.Size = new System.Drawing.Size(141, 21);
            this.patientComboBox.TabIndex = 5;
            this.patientComboBox.SelectedIndexChanged += new System.EventHandler(this.patientComboBox_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(162, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Adgangskode";
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Enabled = false;
            this.passwordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordTextBox.Location = new System.Drawing.Point(192, 203);
            this.passwordTextBox.MaxLength = 4;
            this.passwordTextBox.Multiline = true;
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.PasswordChar = '*';
            this.passwordTextBox.Size = new System.Drawing.Size(120, 29);
            this.passwordTextBox.TabIndex = 3;
            // 
            // loginKnap
            // 
            this.loginKnap.Enabled = false;
            this.loginKnap.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginKnap.Location = new System.Drawing.Point(220, 238);
            this.loginKnap.Name = "loginKnap";
            this.loginKnap.Size = new System.Drawing.Size(92, 33);
            this.loginKnap.TabIndex = 4;
            this.loginKnap.Text = "Log ind";
            this.loginKnap.UseVisualStyleBackColor = true;
            this.loginKnap.Click += new System.EventHandler(this.loginKnap_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Besked:";
            // 
            // mmHgtextBox
            // 
            this.mmHgtextBox.Location = new System.Drawing.Point(502, 129);
            this.mmHgtextBox.Name = "mmHgtextBox";
            this.mmHgtextBox.Size = new System.Drawing.Size(66, 20);
            this.mmHgtextBox.TabIndex = 18;
            // 
            // VolttextBox
            // 
            this.VolttextBox.Location = new System.Drawing.Point(502, 155);
            this.VolttextBox.Name = "VolttextBox";
            this.VolttextBox.Size = new System.Drawing.Size(66, 20);
            this.VolttextBox.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(587, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "mmHg";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(587, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "Volt";
            // 
            // VærditextBox
            // 
            this.VærditextBox.Enabled = false;
            this.VærditextBox.Location = new System.Drawing.Point(502, 181);
            this.VærditextBox.Name = "VærditextBox";
            this.VærditextBox.Size = new System.Drawing.Size(66, 20);
            this.VærditextBox.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(587, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 23;
            this.label9.Text = "Værdi";
            // 
            // StartGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(653, 403);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.VærditextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.VolttextBox);
            this.Controls.Add(this.mmHgtextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.loginKnap);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.patientComboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.opsætningKnap);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.idTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kalibreringKnap);
            this.Name = "StartGUI";
            this.Text = "Startskærm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button kalibreringKnap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox opsætningKnap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox patientComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Button loginKnap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox mmHgtextBox;
        private System.Windows.Forms.TextBox VolttextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox VærditextBox;
        private System.Windows.Forms.Label label9;
    }
}