﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PulsMaalerSystem.Logiklag
{
    class Blodtryk
    {
        private int systole;
        private int diastole;
        private int middeltryk;
        public Blodtryk(int sys, int dia, int middel)
        {
            sys = systole;
            dia = diastole;
            middel = middeltryk;
        }

        private void BeregnSystole()
        {

        }

        private void BeregnDiastole()
        {

        }

        private void BeregnMiddeltryk()
        {

        }
    }
}
