﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PulsMaalerSystem.Datalag;

namespace PulsMaalerSystem.Logiklag
{
    class Blodtryk
    {
        
        //private int systole;
        //private int diastole;
        //private int middeltryk;
        //private List<double> blodtryksliste;
        private const int grænseværdiSys = 100;
        private const int grænseværdiDia = 90;
        private List<int> systoleliste;
        private List<int> diastoleliste;
        //private List<int> middeltrykliste;
        public Blodtryk()
        {
            
            //sys = systole;
            //dia = diastole;
            //middel = middeltryk;
            //blodtryksliste = new List<double>();

            
        }

        public List<int> BeregnSystole(List<double> blodtryksliste)
        {

            double baseline = -5;
            double maxTrykOverBaseline = baseline;
            
            double baselineoverskredet = 0;
            List<int> toppunkter = new List<int>();

            for (int i = 0; i < blodtryksliste.Count - 1; i++)
            {
                if (blodtryksliste[i] > maxTrykOverBaseline)
                {
                    maxTrykOverBaseline = blodtryksliste[i];
                    baselineoverskredet++;
                }
                else
                {
                    if (blodtryksliste[i] < maxTrykOverBaseline && baselineoverskredet > 0)
                    {
                        toppunkter.Add(Convert.ToInt32(blodtryksliste[i - 1]));
                        baselineoverskredet = 0;
                        maxTrykOverBaseline = baseline;
                        i = i + 50;
                    }
                }

            }
            
            return toppunkter;
          
        }

        public List<int> BeregnDiastole(List<double> blodtryksliste)
        {
            diastoleliste = new List<int>();
            for (int i = 0; i < blodtryksliste.Count; i++)
            {
                if (blodtryksliste[i] < grænseværdiDia && blodtryksliste[i] < blodtryksliste[i + 1])
                {
                    diastoleliste.Add((int)blodtryksliste[i]);
                    i += 50;
                }
            }

            return diastoleliste;  
        }

        public List<int> BeregnMiddeltryk(List<int> blodtryksliste)
        {
            int middeltryk;
            List<int> middeltrykliste = new List<int>();
            for (int i = 0; i < blodtryksliste.Count; i++)
           {
               middeltryk = 2 / 3 * diastoleliste[i] + 1 / 3 * systoleliste[i];
               middeltrykliste.Add(middeltryk);

           }
           return middeltrykliste;
        }
    }
}
