﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PulsMaalerSystem.Logiklag;
using System.Threading;

namespace PulsMaalerSystem
{
    public partial class HovedGUI : Form
    {
        LogikLag logik;
        Thread VisEKG;
        Thread VisBT;
        TimeSpan tidTæller;

        public HovedGUI()
        {
            InitializeComponent();
            logik = new LogikLag();
            tidTæller = new TimeSpan();
            //VisEKG = new Thread(TrådEKG);
            //VisBT = new Thread(TrådBT);

            //List<double> Blodtrykliste = logik.hentdata();
            //List<double> EKGliste = logik.hentEKGdata();

        }

        public void TrådEKG()
        {
            EKG.Series["EKG-signal"].Points.DataBindY(logik.hentEKGdata());
        }

        public void TrådBT()
        {
            Blodtryk.Series["Blodtryk-signal"].Points.DataBindY(logik.hentBTdata());
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            tidTextBox.Text = tidTæller.ToString();
            tidTæller += new TimeSpan(0, 0, 1);
        }

        private void tandKnap_Click(object sender, EventArgs e)
        {
            //VisEKG.Start();
            //VisBT.Start();
            timer1.Start();

            tandKnap.Enabled = false;
            slukKnap.Enabled = true;
            filterOff.Enabled = true;
            nulpunktKnap.Enabled = true;

        }

        private void slukKnap_Click(object sender, EventArgs e)
        {
            slukKnap.Enabled = false;
            tandKnap.Enabled = true;
            afbrydKnap.Enabled = true;
            nulpunktKnap.Enabled = false;
            
            timer1.Stop();
        }

        private void filterOff_Click(object sender, EventArgs e)
        {
            if (filterOff.Text.Equals("ON"))
            {
                filterOff.Text = "OFF";
            }

            else
            {
                filterOff.Text = "ON";
            }
        }

        private void afbrydKnap_Click(object sender, EventArgs e)
        {
            StartGUI Startskærm = new StartGUI();

            if(MessageBox.Show("Er du sikker?","Bekræft",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == System.Windows.Forms.DialogResult.Yes)
            {
                Startskærm.Show();
            }
           
            
        }


    }


}
