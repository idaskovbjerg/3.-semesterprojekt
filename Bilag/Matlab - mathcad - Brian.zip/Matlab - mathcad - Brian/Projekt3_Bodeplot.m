%Projekt 3 - bodeplot

clear; clc;
C1 = 340*10^-9;
C2 = 680*10^-9;
R1 = 6600;
R2 = 6600;

x = 1/(C1*C2*R1*R2);

x1 = 1;
x2 = (R1+R2)/(R1*R2*C2);
x3 = 1/(C1*C2*R1*R2);

bodex = tf(x, [x1, x2, x3]);
bodemag(bodex),grid;
hold on;
text(50*6.2831853, -3,'--- Cut-off frequency 50Hz');
text(500*6.2831853, -40, '--- 500Hz');